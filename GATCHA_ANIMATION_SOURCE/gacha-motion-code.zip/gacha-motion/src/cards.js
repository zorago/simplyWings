/* cards.js : 2D cards drawn on a canvas, with a 5x7 pixel font (Minecraft-like, uppercase only).
   card = { tier, x, y, w, h, s (scale), sx (flip squash, |cos|), front, rot (deg), a (alpha),
            gemY, squash, shine 0..1, shineA, tierS, tierA, nameN (letters typed), starsLit [0..1],
            glow, edge (anticipation glow), edgeCol, best (end highlight), big }                       */
(function (G) {
  var U = G.U, P = G.PAL, M = Math;
  var FONT = {
    A: [' ### ', '#   #', '#   #', '#####', '#   #', '#   #', '#   #'], B: ['#### ', '#   #', '#   #', '#### ', '#   #', '#   #', '#### '],
    C: [' ### ', '#   #', '#    ', '#    ', '#    ', '#   #', ' ### '], D: ['#### ', '#   #', '#   #', '#   #', '#   #', '#   #', '#### '],
    E: ['#####', '#    ', '#    ', '#### ', '#    ', '#    ', '#####'], G: [' ### ', '#   #', '#    ', '# ###', '#   #', '#   #', ' ####'],
    H: ['#   #', '#   #', '#   #', '#####', '#   #', '#   #', '#   #'], I: ['#####', '  #  ', '  #  ', '  #  ', '  #  ', '  #  ', '#####'],
    L: ['#    ', '#    ', '#    ', '#    ', '#    ', '#    ', '#####'], M: ['#   #', '## ##', '# # #', '#   #', '#   #', '#   #', '#   #'],
    N: ['#   #', '##  #', '# # #', '#  ##', '#   #', '#   #', '#   #'], O: [' ### ', '#   #', '#   #', '#   #', '#   #', '#   #', ' ### '],
    R: ['#### ', '#   #', '#   #', '#### ', '# #  ', '#  # ', '#   #'], S: [' ####', '#    ', '#    ', ' ### ', '    #', '    #', '#### '],
    T: ['#####', '  #  ', '  #  ', '  #  ', '  #  ', '  #  ', '  #  '], V: ['#   #', '#   #', '#   #', '#   #', '#   #', ' # # ', '  #  '],
    W: ['#   #', '#   #', '#   #', '#   #', '# # #', '## ##', '#   #'], '!': ['  #  ', '  #  ', '  #  ', '  #  ', '  #  ', '     ', '  #  '], ' ': ['', '', '', '', '', '', '']
  };
  /** draw pixel text centred (align 'c') or left; shadow = Minecraft drop shadow */
  G.pixelText = function (ctx, str, x, y, px, col, align) {
    var w = str.length * 6 * px - px, x0 = align === 'c' ? x - w / 2 : x;
    for (var pass = 0; pass < 2; pass++) {
      ctx.fillStyle = pass ? col : 'rgba(7,10,24,.75)'; var o = pass ? 0 : px;
      for (var i = 0; i < str.length; i++) { var g = FONT[str[i]] || FONT[' ']; for (var r = 0; r < 7; r++) for (var c = 0; c < 5; c++) if (g[r] && g[r][c] === '#') ctx.fillRect(x0 + (i * 6 + c) * px + o, y + r * px + o, px + .5, px + .5); }
    }
    return w;
  };
  function chamfer(ctx, w, h, c) { ctx.beginPath(); ctx.moveTo(-w / 2 + c, -h / 2); ctx.lineTo(w / 2 - c, -h / 2); ctx.lineTo(w / 2, -h / 2 + c); ctx.lineTo(w / 2, h / 2 - c); ctx.lineTo(w / 2 - c, h / 2); ctx.lineTo(-w / 2 + c, h / 2); ctx.lineTo(-w / 2, h / 2 - c); ctx.lineTo(-w / 2, -h / 2 + c); ctx.closePath(); }
  function poly(ctx, pts, k, col) { ctx.beginPath(); for (var i = 0; i < pts.length; i += 2) ctx[i ? 'lineTo' : 'moveTo'](pts[i] * k, pts[i + 1] * k); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.stroke(); }
  function star5(ctx, x, y, r, col) { ctx.beginPath(); for (var i = 0; i < 10; i++) { var a = -M.PI / 2 + i * M.PI / 5, rr = i % 2 ? r * .45 : r; ctx[i ? 'lineTo' : 'moveTo'](x + M.cos(a) * rr, y + M.sin(a) * rr); } ctx.closePath(); ctx.fillStyle = col; ctx.fill(); }

  /** placeholder item icons, low poly, coordinates for a 520 px wide card */
  function icon(ctx, kind, t, k) {
    var base = t.rank ? t.col : P.accent, A = U.css(P.white), B = U.css(U.mix(base, P.main, .5)), C = U.css(U.mix(base, P.white, .5)), D = U.css(base), E = U.css(U.mix(base, P.ground, .55));
    if (kind === 'shard') {
      poly(ctx, [0, -175, -72, -62, 4, -12], k, A); poly(ctx, [0, -175, 4, -12, 78, -52], k, C); poly(ctx, [-72, -62, -92, 42, 4, -12], k, B); poly(ctx, [-92, 42, 0, 172, 4, -12], k, E);
      poly(ctx, [4, -12, 0, 172, 88, 52], k, D); poly(ctx, [78, -52, 4, -12, 88, 52], k, C); poly(ctx, [-128, -16, -152, 64, -110, 96, -96, 8], k, C); poly(ctx, [-96, 8, -110, 96, -84, 70], k, D);
      poly(ctx, [118, -92, 146, -20, 120, 6, 104, -40], k, A); poly(ctx, [104, -40, 120, 6, 96, -6], k, B);
    } else if (kind === 'scale') {
      poly(ctx, [0, -160, -112, -62, 0, -20], k, C); poly(ctx, [0, -160, 0, -20, 112, -62], k, A); poly(ctx, [-112, -62, -98, 72, 0, -20], k, D); poly(ctx, [112, -62, 0, -20, 98, 72], k, B);
      poly(ctx, [-98, 72, 0, 165, 0, -20], k, E); poly(ctx, [98, 72, 0, -20, 0, 165], k, D); poly(ctx, [-40, -60, 0, -120, 40, -60, 0, 40], k, A);
    } else { // wings
      [-1, 1].forEach(function (sx) { var m = function (a) { return a.map(function (v, i) { return i % 2 ? v : v * sx; }); };
        poly(ctx, m([14, -40, 160, -165, 126, -62]), k, C); poly(ctx, m([14, -40, 126, -62, 182, -40, 64, 0]), k, D); poly(ctx, m([64, 0, 182, -40, 168, 34]), k, E);
        poly(ctx, m([40, 10, 168, 34, 126, 86, 30, 42]), k, C); poly(ctx, m([30, 42, 126, 86, 74, 118]), k, D); poly(ctx, m([14, -40, 96, -118, 62, -60]), k, A); });
      poly(ctx, [0, -70, 18, -20, 0, 60, -18, -20], k, A);
    }
  }

  G.drawCard = function (ctx, cd, T) {
    var t = G.TIERS[cd.tier], k = cd.w / 520, w = cd.w, h = cd.h, ch = 40 * k;
    if (cd.a <= 0) return;
    ctx.save(); ctx.globalAlpha = cd.a; ctx.translate(cd.x, cd.y); ctx.rotate(cd.rot * M.PI / 180);
    // glow behind
    var gl = M.max(cd.glow || 0, cd.edge || 0, cd.best || 0);
    if (gl > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; var gc = t.rank ? t.col : P.accent, R = M.max(w, h) * (cd.big ? 1 : .95);
      var g = ctx.createRadialGradient(0, 0, 0, 0, 0, R); g.addColorStop(0, U.css(gc, .55 * gl)); g.addColorStop(.5, U.css(gc, .18 * gl)); g.addColorStop(1, U.css(gc, 0)); ctx.fillStyle = g; ctx.fillRect(-R, -R, 2 * R, 2 * R); ctx.restore(); }
    ctx.scale(cd.s * cd.sx, cd.s);
    if (cd.edge > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (var e = 3; e >= 1; e--) { chamfer(ctx, w + e * 10 * k, h + e * 10 * k, ch + e * 4 * k); ctx.strokeStyle = U.css(cd.edgeCol, .25 * cd.edge); ctx.lineWidth = e * 6 * k; ctx.stroke(); } ctx.restore(); }
    // frame
    chamfer(ctx, w, h, ch);
    var fg = ctx.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2), fc = t.rank && cd.front ? t.col : P.white, fd = t.rank && cd.front ? t.deep : P.main;
    fg.addColorStop(0, U.css(fc)); fg.addColorStop(.42, U.css(fd)); fg.addColorStop(.52, U.css(U.mix(fc, P.white, .4))); fg.addColorStop(1, U.css(fd)); ctx.fillStyle = fg; ctx.fill();
    if (t.iridescent && cd.front) { var ir = ctx.createLinearGradient(-w / 2, 0, w / 2, 0), ph = (T * .35) % 1; ir.addColorStop(0, 'rgba(159,244,255,0)'); ir.addColorStop(U.cl(ph), 'rgba(159,244,255,.55)'); ir.addColorStop(U.cl(ph + .25 > 1 ? 1 : ph + .25), 'rgba(255,210,122,.45)'); ir.addColorStop(1, 'rgba(255,210,122,0)'); ctx.fillStyle = ir; ctx.fill(); }
    // inner panel
    var inset = 12 * k; chamfer(ctx, w - 2 * inset, h - 2 * inset, ch - 5 * k); ctx.save(); ctx.clip();
    var ig = ctx.createRadialGradient(0, -h * .08, 0, 0, -h * .08, h * .62);
    if (cd.front) { ig.addColorStop(0, U.css(U.mix(t.rank ? t.col : P.accent, P.ground, .6))); ig.addColorStop(1, U.css(P.ground)); }
    else { ig.addColorStop(0, U.css(P.accent)); ig.addColorStop(1, U.css(U.mix(P.accent, P.ground, .65))); }
    ctx.fillStyle = ig; ctx.fillRect(-w / 2, -h / 2, w, h);
    if (cd.front) {
      ctx.save(); ctx.translate(0, (-30 + (cd.gemY || 0)) * k + 120 * k); ctx.scale(1 / M.sqrt(cd.squash || 1), cd.squash || 1); ctx.translate(0, -120 * k); icon(ctx, t.icon, t, k * (cd.big ? 1 : 1.05)); ctx.restore();
      // tier letters
      ctx.save(); var px = (cd.big ? 16 : 15.5) * k, tx = -w / 2 + 44 * k, ty = -h / 2 + 34 * k; ctx.translate(tx, ty + 3.5 * px); ctx.scale(cd.tierS || 1, cd.tierS || 1); ctx.globalAlpha *= cd.tierA == null ? 1 : cd.tierA;
      G.pixelText(ctx, t.id, 0, -3.5 * px, px, U.css(t.rank ? U.mix(t.col, P.white, .35) : P.white)); ctx.restore();
      // star rating
      var n = cd.starsLit ? cd.starsLit.length : 0;
      for (var s = 0; s < n; s++) { var lit = cd.starsLit[s], sxp = (s - (n - 1) / 2) * 50 * k, syp = 190 * k, rr = 20 * k * (1 + .5 * U.bell(lit, 0, 1) * 0 + (lit > 0 && lit < 1 ? .4 * (1 - lit) : 0));
        star5(ctx, sxp, syp, 20 * k, U.css(U.mix(P.ground, P.main, .4))); if (lit > 0) { ctx.save(); ctx.globalAlpha *= lit; star5(ctx, sxp, syp, rr, U.css(U.mix(t.col, P.white, .3))); ctx.restore(); } }
      // name, typed letter by letter
      var nm = t.item.slice(0, M.min(t.item.length, cd.nameN || 0)); if (nm) G.pixelText(ctx, nm, 0, h / 2 - 74 * k, (cd.big ? 5 : 5.2) * k, U.css(P.white), 'c');
      // shine sweep
      if (cd.shineA > 0) { var sx0 = U.lp(-w, w, cd.shine), sg2 = ctx.createLinearGradient(sx0 - w * .3, -h / 2, sx0 + w * .3, h / 2); sg2.addColorStop(0, 'rgba(255,255,255,0)'); sg2.addColorStop(.5, 'rgba(255,255,255,' + (.55 * cd.shineA).toFixed(3) + ')'); sg2.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sg2; ctx.fillRect(-w / 2, -h / 2, w, h); }
    } else {
      ctx.fillStyle = U.css(P.white); ctx.beginPath(); for (var i = 0; i < 8; i++) { var a = -M.PI / 2 + i * M.PI / 4, r = i % 2 ? 22 * k : 96 * k; ctx[i ? 'lineTo' : 'moveTo'](M.cos(a) * r, M.sin(a) * r); } ctx.closePath(); ctx.fill();
      ctx.fillStyle = U.css(U.mix(P.accent, P.white, .5)); ctx.beginPath(); for (i = 0; i < 8; i++) { a = -M.PI / 2 + i * M.PI / 4; r = i % 2 ? 10 * k : 40 * k; ctx[i ? 'lineTo' : 'moveTo'](M.cos(a) * r, M.sin(a) * r); } ctx.closePath(); ctx.fill();
    }
    ctx.restore(); ctx.restore();
  };
})(globalThis.GM);
