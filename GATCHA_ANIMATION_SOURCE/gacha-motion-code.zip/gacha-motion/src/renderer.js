/* renderer.js : projects state(plan, T) and paints it on a 1920x1080 canvas.
   Painter's algorithm on flat-shaded faces (no z-buffer), additive glows ('lighter').
   In Minecraft: the 3D part becomes ModelParts in a PoseStack, glows/rays/cards become GUI blits. */
(function (G) {
  var U = G.U, M = Math, P_ = G.PAL, PI = M.PI;
  var LD = U.nrm([-.45, .8, .4]), AMB = [.62, .66, .95];

  /** flat shading: moonlight + point lights + emissive + distance fog + global wash / dim */
  function shade(b, n, c, e, st, z) {
    var d = M.max(0, U.dot(n, LD)), r = b[0] * (AMB[0] * .34 + d * .62), g = b[1] * (AMB[1] * .34 + d * .64), bl = b[2] * (AMB[2] * .34 + d * .7);
    for (var i = 0; i < st.Li.length; i++) { var l = st.Li[i], dx = U.sub(l.p, c), dd = U.dot(dx, dx), ndl = M.max(0, U.dot(n, dx) / M.sqrt(dd || 1)), a = M.min(l.I, 4) * (.15 + .85 * ndl) / (1 + dd * .085);
      r += (b[0] * .55 + 34) * l.c[0] / 255 * a; g += (b[1] * .55 + 34) * l.c[1] / 255 * a; bl += (b[2] * .55 + 34) * l.c[2] / 255 * a; }
    if (e) { r = U.lp(r, b[0] * 1.2, e); g = U.lp(g, b[1] * 1.2, e); bl = U.lp(bl, b[2] * 1.2, e); }
    var o = [r, g, bl]; if (z > 40) o = U.mix(o, U.mix(P_.sky, P_.obs2, .4), U.cl((z - 40) / 110) * .7);
    if (st.wash) o = U.mix(o, P_.white, st.wash); if (st.dim) o = U.mix(o, P_.ground, st.dim); return o;
  }

  G.project = function (st) {
    var cam = st.cam, P = cam.pos, fw = cam.fw, rt = cam.rt, up = cam.up, Fo = cam.F, items = [], T = st.T;
    function pj(p) { var d = U.sub(p, P), z = U.dot(d, fw); return [960 + Fo * U.dot(d, rt) / z, 540 - Fo * U.dot(d, up) / z, z]; }
    function face(f, v, oc, idx) {
      var c = v[0], i; for (i = 1; i < v.length; i++) c = U.add(c, v[i]); c = U.scl(c, 1 / v.length);
      var n = U.nrm(U.crs(U.sub(v[1], v[0]), U.sub(v[2], v[0]))), toC = U.sub(P, c);
      if (oc && !f.two) { if (U.dot(n, U.sub(c, oc)) < 0) n = U.scl(n, -1); if (U.dot(n, toC) <= 0) return; } else if (U.dot(n, toC) < 0) n = U.scl(n, -1);
      var pts = [], minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9, zs = 0;
      for (i = 0; i < v.length; i++) { var q = pj(v[i]); if (q[2] < .3) return; pts.push(q[0], q[1]); zs += q[2]; minx = M.min(minx, q[0]); maxx = M.max(maxx, q[0]); miny = M.min(miny, q[1]); maxy = M.max(maxy, q[1]); }
      if (maxx < -60 || minx > 1980 || maxy < -60 || miny > 1140) return;
      var z = zs / v.length, b = f.rgb || P_[f.c], e = f.e, kk = f.k && st.K[f.k]; if (kk) { b = U.mix(b, kk[0], kk[1]); e = M.max(e, kk[1]); }
      var col = f.ly == -2 ? (st.wash ? U.mix(b, P_.white, st.wash * .5) : b) : shade(b, n, c, e, st, z); if (f.ly == -2 && st.dim) col = U.mix(col, P_.ground, st.dim);
      items.push({ o: f.ly == 1 || f.ly == 0 ? f.ly * 1e7 + idx : f.ly * 1e7 + (1e6 - z * 1000), p: pts, f: U.css(col), a: f.op });
    }
    for (var i = 0; i < G.SF.length; i++) face(G.SF[i], G.SF[i].v, G.SF[i].oc, i);
    G.DO.forEach(function (o) { var x = o.xf(st); if (!x) return; var s = x.s || 1;
      function tf(v) { v = U.scl(v, s); if (x.rx) v = U.rX(v, x.rx); if (x.rz) v = U.rZ(v, x.rz); if (x.ry) v = U.rY(v, x.ry); return U.add(v, x.p); }
      o.L.forEach(function (f) { face(f, f.v.map(tf), f.oc ? tf(f.oc) : null, 0); }); });
    st.sp.forEach(function (s) {
      var q = pj(s.p); if (q[2] < .5) return; var k = Fo / q[2], R = s.s * k, x = q[0], y = q[1], j; if (x < -R - 50 || x > 1970 + R || y < -R * 2 - 50 || y > 1130 + R) return;
      var a = s.a == null ? 1 : s.a, r = s.r || 0;
      if (s.k === 'flame') { var h = R * 2.2 * (1 + .12 * M.sin(T * 11 + s.sd)), w = h * .4, sw = M.sin(T * 7 + s.sd * 1.7) * .18 * w, sh = [[-1, 0], [-.85, -.38], [-.4, -.72], [0, -1], [.45, -.6], [.78, -.3], [1, 0], [.5, .16], [-.5, .16]];
        [[s.c, 1, 1, 0], [U.mix(s.c, P_.white, .45), .62, .9, .01], [U.mix(s.c, P_.white, .85), .3, .6, .02]].forEach(function (L) { var p2 = []; sh.forEach(function (v, m) { p2.push(x + v[0] * w * L[1] + sw * -v[1] * (m % 2 ? 1 : .6), y + v[1] * h * L[2] + R * .2); });
          items.push({ o: 2e7 + (1e6 - (q[2] - .4 - L[3] * 10) * 1000), p: p2, f: U.css(st.dim ? U.mix(L[0], P_.ground, st.dim * .5) : L[0]), a: a * .95 }); }); return; }
      var n = s.k === 'star' ? 8 : s.k === 'tri' ? 3 : 4, pts = [];
      for (j = 0; j < n; j++) { var an = r + j * 2 * PI / n - PI / 2, rr = s.k === 'star' ? (j % 2 ? R * .2 : R) : R; pts.push(x + M.cos(an) * rr, y + M.sin(an) * rr); }
      items.push({ o: 2e7 + (1e6 - (q[2] - .2) * 1000), p: pts, f: U.css(st.dim && s.k !== 'star' ? U.mix(s.c, P_.ground, st.dim * .6) : s.c), a: a });
    });
    items.sort(function (a, b) { return a.o - b.o; });
    var rings = []; st.rings.forEach(function (g) { if (g.a <= .01 || g.r < .05) return; var pts = []; for (var j = 0; j < 40; j++) { var an = j * 2 * PI / 40, q = pj([g.c[0] + M.cos(an) * g.r, g.c[1], g.c[2] + M.sin(an) * g.r]); if (q[2] < .5) return; pts.push(q[0], q[1]); } rings.push({ p: pts, c: U.css(g.col), a: g.a, w: g.w * g.a + 1 }); });
    var beam = null; if (st.beam && st.beam.w > .01) { var b0 = pj([0, 3.8, 0]), b1 = pj([0, st.beam.y, 0]); if (b0[2] > .5 && b1[2] > .5) { var dx = b1[0] - b0[0], dy = b1[1] - b0[1], dl = M.hypot(dx, dy) || 1, nx = -dy / dl, ny = dx / dl, w0 = st.beam.w * Fo / b0[2], w1 = st.beam.w * Fo / b1[2] * 3;
      beam = function (f) { return [b0[0] + nx * w0 * f, b0[1] + ny * w0 * f, b1[0] + nx * w1 * f, b1[1] + ny * w1 * f, b1[0] - nx * w1 * f, b1[1] - ny * w1 * f, b0[0] - nx * w0 * f, b0[1] - ny * w0 * f]; }; } }
    var glows = []; st.Li.concat(st.cg).forEach(function (l) { var q = pj(l.p); if (q[2] < .5) return; glows.push({ x: q[0], y: q[1], r: (l.g + M.min(l.I, 3) * .6) * Fo / q[2], c: l.c, a: U.cl(l.I * .3) * (1 - st.dim * .5) }); });
    var sky = PT_SKY(st, fw, rt, up, Fo);
    var fh = U.nrm([fw[0], 0, fw[2]]), hz = 540 - Fo * U.dot(fh, up) / M.max(.05, U.dot(fh, fw));
    var rays = st.rays.map(function (r) { if (r.a <= .005) return null; var xy = r.xy; if (!xy) { var q = pj(r.p); if (q[2] < .5) return null; xy = [q[0], q[1]]; } return { x: xy[0], y: xy[1], r: r }; }).filter(Boolean);
    var cracks = st.cracks.map(function (c) { return { c: c, pl: c.pts.map(function (line) { var n = M.max(2, M.floor(line.length * c.prog)), o = []; for (var j = 0; j < n; j++) { var q = pj(U.add(line[j], P)); if (q[2] < .5) return null; o.push(q[0], q[1]); } return o; }) }; });
    return { items: items, rings: rings, beam: beam, glows: glows, sky: sky, hz: hz, rays: rays, cracks: cracks };
  };
  var SKY = (function () { var r = U.rng(42), a = []; for (var i = 0; i < 170; i++) { var az = r() * 2 * PI, el = M.asin(r() * 1.15 - .18); a.push({ d: [M.cos(el) * M.cos(az), M.sin(el), M.cos(el) * M.sin(az)], s: 1.4 + r() * r() * 4.5, w: .6 + r() * 1.8, p: r() * 7 }); } return a; })();
  function PT_SKY(st, fw, rt, up, Fo) { var o = []; SKY.forEach(function (s) { var z = U.dot(s.d, fw); if (z < .05) return; o.push([960 + Fo * U.dot(s.d, rt) / z, 540 - Fo * U.dot(s.d, up) / z, s.s, U.cl(.35 + .5 * (.5 + .5 * M.sin(st.T * s.w + s.p)) + st.wash) * (1 - st.dim * .6)]); }); return o; }

  function path(ctx, p) { ctx.beginPath(); ctx.moveTo(p[0], p[1]); for (var i = 2; i < p.length; i += 2) ctx.lineTo(p[i], p[i + 1]); ctx.closePath(); }

  /** draw one frame. opts.hud: burn a small timecode (for analysis) */
  G.drawFrame = function (ctx, plan, T, opts) {
    opts = opts || {};
    var st = G.state(plan, T), fr = G.project(st), i;
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    ctx.fillStyle = U.css(P_.ground); ctx.fillRect(0, 0, 1920, 1080);
    ctx.save(); ctx.translate(960 + st.shake[0], 540 + st.shake[1]); ctx.rotate(st.shake[2]); ctx.scale(1.06, 1.06); ctx.translate(-960, -540);
    var g = ctx.createLinearGradient(0, fr.hz - 2000, 0, fr.hz + 2000);
    g.addColorStop(0, U.css(P_.ground)); g.addColorStop(.38, U.css(P_.sky)); g.addColorStop(.5, U.css(U.mix(P_.sky, P_.accent, .4))); g.addColorStop(.53, U.css(P_.obs)); g.addColorStop(.7, U.css(P_.ground)); g.addColorStop(1, U.css(P_.ground));
    ctx.fillStyle = g; ctx.fillRect(-300, -300, 2520, 1680);
    ctx.fillStyle = U.css(P_.white); fr.sky.forEach(function (s) { ctx.globalAlpha = s[3]; ctx.save(); ctx.translate(s[0], s[1]); ctx.rotate(PI / 4); ctx.fillRect(-s[2] / 2, -s[2] / 2, s[2], s[2]); ctx.restore(); }); ctx.globalAlpha = 1;
    ctx.lineJoin = 'round';
    for (i = 0; i < fr.items.length; i++) { var it = fr.items[i]; path(ctx, it.p); ctx.globalAlpha = it.a; ctx.fillStyle = it.f; ctx.fill(); if (it.a >= 1) { ctx.strokeStyle = it.f; ctx.lineWidth = 1.2; ctx.stroke(); } }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'lighter';
    fr.cracks.forEach(function (c) { c.pl.forEach(function (p) { if (!p) return; ctx.beginPath(); ctx.moveTo(p[0], p[1]); for (var j = 2; j < p.length; j += 2) ctx.lineTo(p[j], p[j + 1]);
      ctx.strokeStyle = U.css(c.c.col, .25 * c.c.a); ctx.lineWidth = 18; ctx.stroke(); ctx.strokeStyle = U.css(U.mix(c.c.col, P_.white, .5), .9 * c.c.a); ctx.lineWidth = 4; ctx.stroke(); }); });
    fr.glows.forEach(function (l) { if (l.a < .01 || l.r < 1) return; var rg = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.r); rg.addColorStop(0, U.css(l.c, .85 * l.a)); rg.addColorStop(.45, U.css(l.c, .25 * l.a)); rg.addColorStop(1, U.css(l.c, 0)); ctx.fillStyle = rg; ctx.fillRect(l.x - l.r, l.y - l.r, 2 * l.r, 2 * l.r); });
    ctx.globalCompositeOperation = 'source-over';
    fr.rings.forEach(function (r) { path(ctx, r.p); ctx.strokeStyle = r.c; ctx.globalAlpha = r.a; ctx.lineWidth = r.w; ctx.stroke(); }); ctx.globalAlpha = 1;
    if (fr.beam) { path(ctx, fr.beam(1)); ctx.globalAlpha = .55; ctx.fillStyle = U.css(P_.accent); ctx.fill(); path(ctx, fr.beam(.3)); ctx.globalAlpha = .9; ctx.fillStyle = U.css(P_.white); ctx.fill(); ctx.globalAlpha = 1; }
    ctx.restore();
    // vignette
    var vg = ctx.createRadialGradient(960, 540, 400, 960, 540, 1150); vg.addColorStop(0, 'rgba(7,10,24,0)'); vg.addColorStop(1, 'rgba(7,10,24,.82)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, 1920, 1080);
    // rays
    ctx.globalCompositeOperation = 'lighter';
    fr.rays.forEach(function (o) { var r = o.r, rnd = U.rng(r.seed || 3); for (var j = 0; j < r.n; j++) { var jw = rnd(), an = j * 2 * PI / r.n + jw * .35 + r.rot, w = r.w * (.5 + rnd()), l = r.len * (.6 + .4 * rnd());
      ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(o.x + M.cos(an - w) * l, o.y + M.sin(an - w) * l); ctx.lineTo(o.x + M.cos(an + w) * l, o.y + M.sin(an + w) * l); ctx.closePath();
      ctx.fillStyle = U.css(r.col, r.a * (.6 + .4 * M.sin(st.T * 1.7 + j))); ctx.fill(); } });
    ctx.globalCompositeOperation = 'source-over';
    // cards
    st.cards.forEach(function (c) { G.drawCard(ctx, c, T); });
    // 2D particles of card bursts
    ctx.globalCompositeOperation = 'lighter';
    st.fx2d.forEach(function (q) { ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot); ctx.fillStyle = U.css(q.col, q.a); ctx.beginPath(); if (q.k === 'tri') { ctx.moveTo(0, -q.s); ctx.lineTo(q.s * .87, q.s * .5); ctx.lineTo(-q.s * .87, q.s * .5); } else { ctx.moveTo(0, -q.s); ctx.lineTo(q.s * .6, 0); ctx.lineTo(0, q.s); ctx.lineTo(-q.s * .6, 0); } ctx.closePath(); ctx.fill(); ctx.restore(); });
    ctx.globalCompositeOperation = 'source-over';
    if (st.flash > 0) { ctx.fillStyle = U.css(P_.white, st.flash); ctx.fillRect(0, 0, 1920, 1080); }
    if (opts.hud) { ctx.fillStyle = 'rgba(7,10,24,.55)'; ctx.fillRect(16, 1080 - 52, 520, 36); ctx.fillStyle = 'rgba(238,242,248,.9)'; ctx.font = '22px monospace'; ctx.fillText(opts.hud + '  t=' + T.toFixed(2) + 's  f=' + M.round(T * 30), 26, 1080 - 26); }
    ctx.restore();
    return st;
  };
})(globalThis.GM);
