/* anims.js : the animations rendered as previews. Add / edit pull lists here. */
(function (G) {
  G.ANIMS = {
    single_b:   ['B'],
    single_a:   ['A'],
    single_s:   ['S'],
    single_ss:  ['SS'],
    single_sss: ['SSS'],
    multi_x10:  ['B', 'B', 'B', 'B', 'B', 'B', 'A', 'S', 'SS', 'SSS'],
    multi_x10_double_sss: ['B', 'A', 'B', 'SSS', 'B', 'S', 'B', 'A', 'B', 'SSS']
  };
})(globalThis.GM);
