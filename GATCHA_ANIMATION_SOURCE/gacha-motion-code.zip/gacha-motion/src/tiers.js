/* tiers.js : palette and per-rarity tuning. THIS is the file to tweak first.
   Every timing below is in seconds. "power" scales particles, shake, rings and light. */
(function (G) {
  var U = G.U, H = U.hex;

  /** Scene palette (low poly End sky, obsidian, bone, the four altar flames). */
  G.PAL = {
    ground: H('#070A18'), sky: H('#1D1546'), main: H('#8E9AAB'), white: H('#EEF2F8'),
    accent: H('#9B5CFF'), obs: H('#221A3A'), bone: H('#E4DAC4'),
    blue: H('#4FA8FF'), red: H('#FF4A5E'), green: H('#46E08A')
  };
  var P = G.PAL;
  P.rock = U.mix(P.obs, P.main, .3); P.obs2 = U.mix(P.obs, P.accent, .25);
  P.feather = U.mix(P.white, P.main, .3); P.mem = U.mix(P.red, P.obs, .45); P.mem2 = U.mix(P.red, P.obs, .62);
  P.horn = U.mix(P.bone, P.main, .4);
  /** the four pillar flames, lit in this order during the fall (user request: blue, red, white, green) */
  G.FLAMES = ['blue', 'red', 'white', 'green'];

  /** Rarity table. Colours = GachaTier signal colours of the spec.
      chain     : colours the star passes through while it falls (single pull), one "beat" each.
      fallExtra : extra seconds of fall (single) on top of the 3 s of a B.
      hold      : stop-time above the bowl before the burst (single).
      cardDur   : seconds of the card reveal (single).
      spawn     : seconds a star takes to arrive in the sky (multi) before the next one spawns.
      flip      : seconds a card takes to flip in the ×10 grid, anticipation included.
      gap       : seconds from this card's flip to the next card's flip (×10).            */
  G.TIERS = {
    B:   { id: 'B',   rank: 0, col: H('#DDE4EA'), deep: H('#5B6676'), chain: [],                     fallExtra: 0,   hold: .7,  cardDur: 4.0, stars: 0, power: 1.0, spawn: .42, flip: .30, gap: .36, item: 'END SHARD',     icon: 'shard' },
    A:   { id: 'A',   rank: 1, col: H('#5AA9FF'), deep: H('#1C3F7A'), chain: ['A'],                  fallExtra: .5,  hold: .8,  cardDur: 4.3, stars: 0, power: 1.3, spawn: .58, flip: .45, gap: .62, item: 'DRAGON SCALE',  icon: 'scale' },
    S:   { id: 'S',   rank: 2, col: H('#B46CFF'), deep: H('#3D1A72'), chain: ['A', 'S'],             fallExtra: 1.1, hold: 1.0, cardDur: 5.0, stars: 3, power: 1.8, spawn: 1.0, flip: .95, gap: 1.35, item: 'VIOLET WINGS', icon: 'wings' },
    SS:  { id: 'SS',  rank: 3, col: H('#FFC23A'), deep: H('#6B3E08'), chain: ['A', 'S', 'SS'],       fallExtra: 1.8, hold: 1.2, cardDur: 5.6, stars: 4, power: 2.5, spawn: 1.4, flip: 1.35, gap: 1.85, item: 'GOLDEN WINGS', icon: 'wings' },
    SSS: { id: 'SSS', rank: 4, col: H('#FF4A5E'), deep: H('#5A0D1E'), chain: ['A', 'S', 'SS', 'SSS'], fallExtra: 2.6, hold: 1.5, cardDur: 6.4, stars: 5, power: 3.3, spawn: 1.95, flip: 1.9, gap: 2.7, item: 'CRIMSON WINGS', icon: 'wings', iridescent: true }
  };
  G.TIER_ORDER = ['B', 'A', 'S', 'SS', 'SSS'];
  /** best tier of a pull list */
  G.best = function (pulls) { var b = G.TIERS.B; pulls.forEach(function (p) { if (G.TIERS[p].rank > b.rank) b = G.TIERS[p]; }); return b; };
  /** star colour for a tier; SSS gets a slow iridescent shift (cyan / gold glints) */
  G.tierCol = function (id, T) {
    var t = G.TIERS[id];
    if (id === 'B') return P.white;
    if (t.iridescent) { var k = .5 + .5 * Math.sin(T * 2.3); return U.mix(t.col, k > .5 ? H('#9FF4FF') : H('#FFD27A'), .22 * Math.abs(k - .5) * 2); }
    return t.col;
  };
})(globalThis.GM);
