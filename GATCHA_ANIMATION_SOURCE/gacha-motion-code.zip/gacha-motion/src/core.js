/* core.js : maths, easing, random, colours.
   Everything in this project is a PURE FUNCTION OF TIME: state(plan, T) never
   depends on the previous frame, so any frame can be rendered in any order
   (scrubbing, export, Java port: tick -> T = ticks/20 + partialTick/20). */
(function (G) {
  var M = Math;
  var U = G.U = {};
  U.PI = M.PI;
  U.cl = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
  /** progress 0..1 of t between a and b */
  U.sg = function (t, a, b) { return b <= a ? (t >= a ? 1 : 0) : U.cl((t - a) / (b - a)); };
  U.lp = function (a, b, u) { return a + (b - a) * u; };
  U.eo = function (x) { return 1 - (1 - x) * (1 - x) * (1 - x); };          // easeOutCubic
  U.ei = function (x) { return x * x * x; };                                 // easeInCubic
  U.eio = function (x) { return x < .5 ? 4 * x * x * x : 1 - M.pow(-2 * x + 2, 3) / 2; }; // easeInOutCubic
  U.eox = function (x) { return x >= 1 ? 1 : 1 - M.pow(2, -10 * x); };       // easeOutExpo
  U.eob = function (x, s) { s = s || 1.7; x = x - 1; return 1 + (s + 1) * x * x * x + s * x * x; }; // easeOutBack
  /** a bell 0 -> 1 -> 0 over [a, b] */
  U.bell = function (t, a, b) { var u = U.sg(t, a, b); return u <= 0 || u >= 1 ? 0 : M.sin(M.PI * u); };
  /** a short hit: 0 before t0, 1 at t0, exponential decay of rate k */
  U.hit = function (t, t0, k) { return t < t0 ? 0 : M.exp(-(t - t0) * k); };
  /** deterministic PRNG (mulberry32) */
  U.rng = function (s) { return function () { s |= 0; s = s + 0x6D2B79F5 | 0; var t = M.imul(s ^ s >>> 15, 1 | s); t = t + M.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };

  /* vectors [x, y, z], y up */
  U.sub = function (a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; };
  U.add = function (a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; };
  U.scl = function (a, s) { return [a[0] * s, a[1] * s, a[2] * s]; };
  U.dot = function (a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; };
  U.crs = function (a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; };
  U.nrm = function (a) { var l = M.sqrt(U.dot(a, a)) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  U.vl = function (a, b, u) { return [U.lp(a[0], b[0], u), U.lp(a[1], b[1], u), U.lp(a[2], b[2], u)]; };
  U.rY = function (v, a) { var c = M.cos(a), s = M.sin(a); return [v[0] * c + v[2] * s, v[1], -v[0] * s + v[2] * c]; };
  U.rZ = function (v, a) { var c = M.cos(a), s = M.sin(a); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2]]; };
  U.rX = function (v, a) { var c = M.cos(a), s = M.sin(a); return [v[0], v[1] * c - v[2] * s, v[1] * s + v[2] * c]; };

  /* colours as [r, g, b] 0..255 */
  U.hex = function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; };
  U.mix = function (a, b, u) { return [U.lp(a[0], b[0], u), U.lp(a[1], b[1], u), U.lp(a[2], b[2], u)]; };
  U.css = function (c, a) {
    var s = M.round(M.max(0, M.min(255, c[0]))) + ',' + M.round(M.max(0, M.min(255, c[1]))) + ',' + M.round(M.max(0, M.min(255, c[2])));
    return a == null ? 'rgb(' + s + ')' : 'rgba(' + s + ',' + M.max(0, M.min(1, a)).toFixed(3) + ')';
  };

  /** Smooth key curve (cubic Hermite / Catmull-Rom), keys = [[t, v], ...]; flat at both ends. */
  U.key = function (K, T) {
    var n = K.length; if (T <= K[0][0]) return K[0][1]; if (T >= K[n - 1][0]) return K[n - 1][1];
    var i = 0; while (T > K[i + 1][0]) i++;
    var p1 = K[i], p2 = K[i + 1], p0 = K[i - 1] || p1, p3 = K[i + 2] || p2, h = p2[0] - p1[0], u = (T - p1[0]) / h;
    var m1 = i == 0 ? 0 : (p2[1] - p0[1]) / (p2[0] - p0[0]) * h, m2 = i + 2 >= n ? 0 : (p3[1] - p1[1]) / (p3[0] - p1[0]) * h;
    var u2 = u * u, u3 = u2 * u;
    return (2 * u3 - 3 * u2 + 1) * p1[1] + (u3 - 2 * u2 + u) * m1 + (-2 * u3 + 3 * u2) * p2[1] + (u3 - u2) * m2;
  };
  /** Integral of a piecewise-linear curve (used for camera orbit: keys are angular SPEEDS in rad/s) */
  U.integ = function (K, T) {
    var s = 0, n = K.length;
    for (var i = 0; i < n - 1; i++) { var a = K[i], b = K[i + 1]; if (T <= a[0]) break; var e = M.min(T, b[0]), ve = a[1] + (b[1] - a[1]) * (e - a[0]) / (b[0] - a[0]); s += (a[1] + ve) / 2 * (e - a[0]); }
    if (T > K[n - 1][0]) s += K[n - 1][1] * (T - K[n - 1][0]);
    return s;
  };
  /** piecewise-linear remap of T from anchor list A to anchor list B */
  U.remap = function (T, A, B) {
    if (T <= A[0]) return B[0] + (T - A[0]);
    for (var i = 0; i < A.length - 1; i++) if (T <= A[i + 1]) return U.lp(B[i], B[i + 1], (T - A[i]) / (A[i + 1] - A[i]));
    return B[B.length - 1] + (T - A[A.length - 1]);
  };
})(globalThis.GM = globalThis.GM || {});
