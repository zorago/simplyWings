/* altar.js : the low poly scene, as plain faces. One unit = one Minecraft block.
   Y is up, the bowl is at the origin. To rebuild it in Blockbench, read the
   "PARTS" comments: every primitive below is a prism / cone / bipyramid with
   explicit radius, heights and position.

   Face = { v:[[x,y,z]...], c:paletteKey, e:emissive 0..1, k:dynamicKey, two:doubleSided,
            oc:primitiveCentre (outward normal test), ly:layer, rgb:explicitColour, op:opacity }
   Layers: -2 sky dome, -1 far islands, 0 island floor + runes, 1 stepped platform
   (drawn in construction order), 2 everything else (depth sorted).            */
(function (G) {
  var U = G.U, M = Math, PI = M.PI, P = G.PAL;
  var cur = 0;
  function F(L, v, c, o) { o = o || {}; L.push({ v: v, c: c, e: o.e || 0, k: o.k, two: o.two, oc: o.oc, ly: cur, rgb: o.rgb, op: o.op == null ? 1 : o.op }); }
  function ring(n, r, y, a0, ox, oz) { var p = []; for (var i = 0; i < n; i++) { var a = a0 + i * 2 * PI / n; p.push([ox + M.cos(a) * r, y, oz + M.sin(a) * r]); } return p; }
  /** n-sided frustum (prism when r0 == r1). caps: 1 = top, 2 = bottom */
  function frus(L, n, r0, r1, y0, y1, c, a0, ox, oz, caps, co) {
    a0 = a0 || 0; ox = ox || 0; oz = oz || 0; var oc = [ox, (y0 + y1) / 2, oz], A = ring(n, r0, y0, a0, ox, oz), B = ring(n, r1, y1, a0, ox, oz);
    for (var i = 0; i < n; i++) { var j = (i + 1) % n; F(L, [A[i], A[j], B[j], B[i]], c, { oc: oc }); }
    co = co || {}; if (caps & 1) F(L, B, co.c || c, { oc: oc, k: co.k, e: co.e }); if (caps & 2) F(L, A.slice().reverse(), c, { oc: oc });
  }
  function cone(L, n, r, y0, y1, c, a0, ox, oz) { ox = ox || 0; oz = oz || 0; var A = ring(n, r, y0, a0 || 0, ox, oz), tp = [ox, y1, oz], oc = [ox, y0 + (y1 - y0) * .3, oz]; for (var i = 0; i < n; i++) F(L, [A[i], A[(i + 1) % n], tp], c, { oc: oc }); }
  function bipy(L, n, r, h0, h1, c, o) { o = o || {}; var A = ring(n, r, 0, 0, 0, 0), oc = [0, 0, 0]; for (var i = 0; i < n; i++) { var j = (i + 1) % n; F(L, [A[i], A[j], [0, h1, 0]], c, { oc: oc, e: o.e, k: o.k }); F(L, [A[j], A[i], [0, -h0, 0]], c, { oc: oc, e: o.e, k: o.k }); } }
  function xr(L, s, fn) { for (var i = s; i < L.length; i++) { L[i].v = L[i].v.map(fn); if (L[i].oc) L[i].oc = fn(L[i].oc); } }
  /** a feather / vane: kite along +y from the origin, folded on its quill */
  function kite(L, len, w, tw, c1, c2) { var m = len * .36; F(L, [[0, 0, 0], [-w, m, tw], [0, len, 0], [0, m * 1.1, -tw * .4]], c1, { two: 1 }); F(L, [[0, 0, 0], [0, m * 1.1, -tw * .4], [0, len, 0], [w, m, tw]], c2, { two: 1 }); }

  var SF = [], DO = [];
  /** pillar i stands at angle PI/4 + i*PI/2, radius 4.6; flame sits on top at y 5.5 */
  G.PILLARS = [0, 1, 2, 3].map(function (i) { var a = PI / 4 + i * PI / 2; return [M.cos(a) * 4.6, 5.5, M.sin(a) * 4.6]; });
  G.BOWL = [0, 3.75, 0];

  (function build() {
    var L = SF, r = U.rng(7), i, s;
    /* PART sky dome: 16 x 5 faceted bands, radius 420, violet near the horizon, darker at the zenith */
    cur = -2; var lat = [-.34, -.02, .28, .6, .92, 1.22], nl = 16, R = 420;
    function dp(a, l) { return [M.cos(a) * M.cos(l) * R, M.sin(l) * R, M.sin(a) * M.cos(l) * R]; }
    for (var b = 0; b < lat.length - 1; b++) for (i = 0; i < nl; i++) {
      var a0 = i * 2 * PI / nl + b * .21, a1 = (i + 1) * 2 * PI / nl + b * .21, h = U.cl((lat[b] + .34) / 1.5);
      var base = U.mix(U.mix(P.obs2, P.sky, .45 + r() * .55), P.ground, h * .55); if (r() < .2) base = U.mix(base, P.accent, .22);
      F(L, [dp(a0, lat[b]), dp(a1, lat[b]), dp(a1, lat[b + 1])], 'x', { two: 1, rgb: base, e: 1, op: .85 });
      F(L, [dp(a0, lat[b]), dp(a1, lat[b + 1]), dp(a0, lat[b + 1])], 'x', { two: 1, rgb: U.mix(base, P.ground, .12 + r() * .1), e: 1, op: .85 });
    }
    for (i = 0; i < nl; i++) { var q = lat[lat.length - 1]; F(L, [dp(i * 2 * PI / nl, q), dp((i + 1) * 2 * PI / nl, q), [0, R, 0]], 'x', { two: 1, rgb: U.mix(P.ground, P.sky, .3 + r() * .12), e: 1, op: .85 }); }
    /* PART far islands: 9 floating End islands (hex frustum + hanging cone + optional spire), 50-95 blocks away */
    cur = -1; for (i = 0; i < 9; i++) { var a = i * .7 + r() * .5, d = 50 + r() * 45, x = M.cos(a) * d, z = M.sin(a) * d, y = -5 + r() * 22, sz = 3 + r() * 6; cone(L, 6, sz * .85, y - sz * .25, y - sz * 1.7, 'obs', r() * 3 + .3, x, z); frus(L, 6, sz * .85, sz, y - sz * .25, y, 'rock', r() * 3, x, z, 1); if (r() < .6) frus(L, 5, sz * .16, sz * .1, y, y + sz * 1.1, 'obs', 0, x + sz * .3, z, 1); }
    /* PART island: decagon r 9.6 at y 0, rock skirt to y -1.4, three hanging obsidian cones */
    cur = 0; cone(L, 10, 7.6, -1.4, -8.5, 'obs', .1, 0, 0); cone(L, 7, 4, -1.4, -12, 'obs', .5, 2, 1); cone(L, 6, 3, -1.4, -9, 'obs', 1.1, -3, -2); frus(L, 10, 7.6, 9.6, -1.4, 0, 'rock', .1, 0, 0, 1);
    /* PART rune ring: 24 floor segments, radius 6.15 to 6.95. They light one by one = the loader. key r0..r23 */
    for (i = 0; i < 24; i++) { var b0 = i * 2 * PI / 24 + .035, b1 = (i + 1) * 2 * PI / 24 - .035; F(L, [[M.cos(b0) * 6.15, .03, M.sin(b0) * 6.15], [M.cos(b1) * 6.15, .03, M.sin(b1) * 6.15], [M.cos(b1) * 6.95, .03, M.sin(b1) * 6.95], [M.cos(b0) * 6.95, .03, M.sin(b0) * 6.95]], 'obs2', { two: 1, k: 'r' + i }); }
    /* PART stepped platform: three octagonal tiers (r 5.7/4.45/3.25, 0.5 high each) */
    cur = 1; frus(L, 8, 5.7, 5.35, 0, .5, 'obs', PI / 8, 0, 0, 1); frus(L, 8, 4.45, 4.15, .5, 1.0, 'rock', 0, 0, 0, 1); frus(L, 8, 3.25, 2.95, 1.0, 1.5, 'obs', PI / 8, 0, 0, 1);
    /* PART pedestal (bone hex, y 1.5-3) and bowl (obsidian octagon flaring to r 1.9 at y 3.75, glowing inside: key bowl) */
    cur = 2; frus(L, 6, 1.25, .85, 1.5, 3.0, 'bone', 0, 0, 0, 0); frus(L, 8, .9, 1.9, 3.0, 3.75, 'obs', PI / 8, 0, 0, 0);
    s = L.length; frus(L, 8, 1.9, 1.5, 3.75, 3.45, 'obs2', PI / 8, 0, 0, 1, { k: 'bowl' }); for (var j = s; j < L.length; j++) { L[j].two = 1; L[j].oc = null; }
    /* PART 4 pillars: obsidian plinth, bone shaft (pentagon r .5 -> .4, y .95-5), obsidian capital (key c0..c3, glows with its flame),
       2 horns each, and one small floor crystal between pillars */
    for (i = 0; i < 4; i++) (function (i) {
      var a = PI / 4 + i * PI / 2, px = M.cos(a) * 4.6, pz = M.sin(a) * 4.6;
      frus(L, 4, .66, .62, .5, .95, 'obs', a + PI / 4, px, pz, 1); frus(L, 5, .5, .4, .95, 5.0, 'bone', a, px, pz, 0); frus(L, 5, .4, .82, 5.0, 5.5, 'obs', a, px, pz, 1, { k: 'c' + i, c: 'obs2' });
      for (var g = -1; g <= 1; g += 2) { var s2 = L.length; cone(L, 4, .2, 0, 1.9, 'horn', .4, 0, 0); xr(L, s2, function (v) { v = U.rZ(v, g * .6); v = U.rY(v, -a + PI / 2); return [v[0] + px, v[1] + 4.8, v[2] + pz]; }); }
      var s3 = L.length; bipy(L, 4, .28, .2, .95, 'accent', { e: .25, k: 'cry' }); var bb = a + PI / 4; xr(L, s3, function (v) { return [v[0] + M.cos(bb) * 5.05, v[1] + .7, v[2] + M.sin(bb) * 5.05]; });
    })(i);
    /* PART feather wing (left, white): 6 long feathers fanning from (-1.05, 3.4) + 4 coverts */
    [[.3, 4.6], [.6, 5.4], [.9, 5.2], [1.2, 4.6], [1.5, 3.8], [1.8, 3.0]].forEach(function (q, k) { var s4 = L.length; kite(L, q[1], .66, .28, 'white', 'feather'); xr(L, s4, function (v) { v = U.rX(v, k % 2 ? .16 : -.12); v = U.rZ(v, q[0]); return [v[0] - 1.05, v[1] + 3.4, v[2] - .25]; }); });
    [[.45, 2.4], [.85, 2.6], [1.25, 2.3], [1.65, 1.9]].forEach(function (q) { var s5 = L.length; kite(L, q[1], .5, .2, 'bone', 'feather'); xr(L, s5, function (v) { v = U.rZ(v, q[0]); return [v[0] - 1.05, v[1] + 3.4, v[2] + .05]; }); });
    /* PART membrane wing (right, red): 5 bone spars from (1.05, 3.4) with membranes between them */
    var Pv = [1.05, 3.4, -.2], T = [[3.4, 8.4, -.5], [6.3, 6.9, -.8], [7.3, 4.2, -.6], [6.0, 1.9, -.3], [3.7, 1.3, -.1]];
    for (i = 0; i < T.length - 1; i++) { var mid = U.vl(U.vl(T[i], T[i + 1], .5), Pv, .2); F(L, [Pv, T[i], mid, T[i + 1]], i % 2 ? 'mem2' : 'mem', { two: 1 }); }
    T.forEach(function (t) { var d = U.nrm(U.sub(t, Pv)), pr = U.scl(U.nrm(U.crs(d, [0, 0, 1])), .11); F(L, [U.add(Pv, pr), U.add(t, U.scl(pr, .4)), U.sub(t, U.scl(pr, .4)), U.sub(Pv, pr)], 'horn', { two: 1 }); });

    /* DYNAMIC PARTS: their transform {p, rx, ry, rz, s} comes from state() every frame */
    function dyn(fn, xf) { var L2 = []; fn(L2); DO.push({ L: L2, xf: xf }); }
    dyn(function (L) { bipy(L, 6, .8, 1.1, 1.8, 'accent', { e: .3, k: 'cry' }); }, function (st) { return st.cry; });          // floating crystal above the bowl
    for (i = 0; i < 8; i++) (function (i) { dyn(function (L) { bipy(L, 4, .3, .35, .75, 'accent', { e: .25, k: 'cry' }); }, function (st) { return st.sh[i]; }); })(i); // 8 orbiting shards
    for (i = 0; i < 10; i++) (function (i) { dyn(function (L) { kite(L, 2.5, .42, .14, 'white', 'feather'); kite(L, 1.1, .25, .08, 'bone', 'feather'); L.forEach(function (f) { f.k = 'fe'; }); }, function (st) { return st.fe[i]; }); })(i); // summoning feathers (1 or 10)
  })();
  G.SF = SF; G.DO = DO;
})(globalThis.GM);
