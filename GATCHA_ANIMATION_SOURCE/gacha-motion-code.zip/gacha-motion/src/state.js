/* state.js : WORLD STATE AT TIME T. state(plan, T) -> everything the renderer draws.
   No memory between frames (a few geometry caches keyed by the plan only).

   Output:
   st.cam    {pos, fw, rt, up, F}     camera basis + focal length in px
   st.shake  [dx, dy, roll]           screen shake
   st.K      {key: [rgb, amount]}     dynamic colours of keyed faces (runes, bowl, capitals, crystal, feathers)
   st.Li     [{p, c, I, g}]           point lights (also drawn as glows)
   st.cg     [{p, c, I, g}]           glow-only lights
   st.sp     [sprite]                 3D billboards: star | dia | tri | flame
   st.rings  [{c, r, a, w, col, up}]  3D rings (ground shock waves, sky rings)
   st.rays   [{p|xy, n, len, a, col, rot, w}]  light rays in screen space around a projected point
   st.cracks [{pts3d, prog, a}]       SSS sky cracks
   st.flash  0..1                     full screen white (WCAG: max 3/s, <= .7 except the SSS impact .85)
   st.cards  [card]                   2D cards (see cards.js)
   st.fx2d   [particle]               2D particles of the card bursts
   st.dim, st.wash                    global darkening / whitening of the 3D scene                       */
(function (G) {
  var U = G.U, M = Math, PI = M.PI, P_ = G.PAL, TI = G.TIERS;
  var sg = U.sg, lp = U.lp, eo = U.eo, ei = U.ei, eio = U.eio, eob = U.eob, bell = U.bell, hit = U.hit, vl = U.vl, mix = U.mix;

  /* ---------------- particles seeded once ---------------- */
  var R0 = U.rng(42), PT = {};
  function arr(n, f) { var a = []; for (var i = 0; i < n; i++) a.push(f(i)); return a; }
  function dir(a, e) { return [M.cos(a) * M.cos(e), M.sin(e), M.sin(a) * M.cos(e)]; }
  PT.sky = arr(170, function () { var az = R0() * 2 * PI, el = M.asin(R0() * 1.15 - .18); return { d: dir(az, el), s: 1.4 + R0() * R0() * 4.5, w: .6 + R0() * 1.8, p: R0() * 7 }; });
  PT.ember = arr(60, function (i) { return { b: i * .021, v: 1.6 + R0() * 2.2, a: R0() * 7, r: .2 + R0() * .7, l: .8 + R0() * .7, c: R0() < .6 ? 'accent' : 'white' }; });
  PT.mote = arr(40, function (i) { return { b: 2.35 + i * .042, a: R0() * 2 * PI, l: .85 + R0() * .3, c: R0() < .5 ? 'accent' : 'white' }; });
  PT.dust = arr(46, function (i) { return { b: i / 46, o: [(R0() - .5) * 2.4, (R0() - .5) * 1.6, (R0() - .5) * 2.4], l: 1.1 + R0() * .6, v: .5 + R0() * .6 }; });
  PT.comp = arr(12, function () { return { r: 5.4 + R0() * 3.2, h: 2.6 + R0() * 4.8, w: .75 + R0() * .6, p: R0() * 7, z: .32 + R0() * .16 }; });
  PT.ign = arr(4, function () { return arr(14, function () { return { d: dir(R0() * 2 * PI, .3 + R0() * 1.1), v: 3 + R0() * 4, l: .6 + R0() * .5 }; }); });
  PT.eru = arr(34, function (i) { return { d: dir(R0() * 2 * PI, .5 + R0()), v: 5 + R0() * 7, l: .8 + R0() * .6, c: G.FLAMES[i % 4] }; });
  PT.boom = arr(110, function (i) { return { d: dir(R0() * 2 * PI, M.asin(R0() * 1.6 - .6)), v: 9 + R0() * 17, l: 1 + R0() * .9, s: .3 + R0() * .55, ci: i % 6, rr: (R0() - .5) * 14 }; });
  PT.glint = arr(36, function () { return { a: R0() * 2 * PI, r: 2 + R0() * 7, y: R0() * 6 - 1, v: .25 + R0() * .5, p: R0() * 7, l: 2 + R0() * 1.5 }; });
  PT.spawn = arr(10, function () { return arr(26, function () { return { d: dir(R0() * 2 * PI, M.asin(R0() * 2 - 1)), v: 2 + R0() * 6, l: .5 + R0() * .7 }; }); });
  PT.card = arr(10, function () { return arr(70, function () { var a = R0() * 2 * PI; return { a: a, v: 150 + R0() * 650, l: .5 + R0() * .9, s: 4 + R0() * 10, rr: (R0() - .5) * 12, k: R0() < .5 ? 'dia' : 'tri' }; }); });

  function flameCol(T, k, t0) { var x = ((T - t0) * .9 + k) % 4; if (x < 0) x += 4; var i = M.floor(x); return mix(P_[G.FLAMES[i]], P_[G.FLAMES[(i + 1) % 4]], eio(x - i)); }
  function tierRGB(id, T) { return G.tierCol(id, T); }

  /* ---------------- single pull: the one star ---------------- */
  function starSingle(P, T) {
    var D0 = P.T.fall, D1 = P.T.fallEnd, B = P.T.boom, ex = P.best.fallExtra;
    if (T < D0) { var u = sg(T, 4.4, D0), ph = .4 + u * 1.3, r = 9 - 1.5 * u; return [M.cos(ph) * r, lp(33, 26, u), M.sin(ph) * r]; }
    if (T < D1) { var v = (T - D0) / P.Ld, ph2 = 1.7 + (v * 1.4 + v * v * 3.4 * (1 + ex * .45)) * PI, r2 = (7.5 + .7 * M.sin(T * 2.3) * (1 - v)) * (1 - eio(sg(v, .8, 1))), y = v < .55 ? lp(26, 9.5, eo(v / .55)) : lp(9.5, 7.5, eio((v - .55) / .45)); return [M.cos(ph2) * r2, y + .4 * M.sin(T * 3.1) * (1 - v), M.sin(ph2) * r2]; }
    return [0, 7.5 + .12 * M.sin(T * 4) * (T < B ? 1 : 0), 0];
  }
  function beatPulse(P, T) { var k = 1; P.beats.forEach(function (b) { k *= 1 - .35 * bell(T, b.t, b.t + .2); k += .3 * bell(T, b.t + .15, b.t + .5); }); return k; }
  function sizeSingle(P, T) {
    var D0 = P.T.fall, D1 = P.T.fallEnd, B = P.T.boom;
    if (T < 4.4) return 0;
    if (T < D0) return eo(sg(T, 4.4, 4.95)) * (1.15 + .08 * M.sin(T * 2.4));
    if (T < D1) return lp(1.15, 1, sg(T, D0, D0 + .7)) * (1 + .22 * P.best.rank * sg(T, D0, D1)) * beatPulse(P, T);
    var top = 1 + .22 * P.best.rank;
    if (T < B - .15) return lp(top, .5, eio(sg(T, D1, B - .15)));
    if (T < B) return lp(.5, 2.4 * (.8 + .2 * P.best.power), ei(sg(T, B - .15, B)));
    return 0;
  }
  function colSingle(P, T) { var c = P_.white; P.beats.forEach(function (b) { c = mix(c, tierRGB(b.tier, T), sg(T, b.t, b.t + .15)); }); return c; }

  /* ---------------- ×10 pull: ten stars in a sky ring ---------------- */
  function slot(i, T) { var a = i * 2 * PI / 10 + .35 * (T - 4.6), r = 10 + 1.2 * M.sin(T * 1.3 + i), y = 25 + 1.4 * M.sin(T * .9 + i * 1.7); return { a: a, r: r, y: y, p: [M.cos(a) * r + .9 * M.cos(T * 2.2 + i), y + .5 * M.sin(T * 2.9 + i), M.sin(a) * r + .9 * M.sin(T * 2.2 + i)] }; }
  function startFor(id, s) { var p = s.p; return id === 'B' ? p : id === 'A' ? [p[0], p[1] + 14, p[2]] : id === 'S' ? [p[0] * .5, p[1] + 30, p[2] * .5] : id === 'SS' ? [0, 75, 0] : [p[0] * 3.5, 45, p[2] * 3.5]; }
  function starMulti(P, i, T) {
    var id = P.pulls[i], t = TI[id], s0 = P.spawn[i], ad = t.spawn * .7, f = P.fallWin[i];
    if (T < s0) return null;
    var S = slot(i, T), base = [.7, .75, .9, 1.0, 1.15][t.rank], u = sg(T, s0, s0 + ad);
    var p = vl(startFor(id, slot(i, s0)), S.p, t.rank ? U.eox(u) : eo(u));
    var size = base * (t.rank ? sg(T, s0, s0 + .08) : eo(u)) * (1 + (.25 + .2 * t.rank) * bell(T, s0 + ad - .05, s0 + ad + .4));
    if (T > f[0]) { var v = sg(T, f[0], f[1]); if (v >= 1) return { landed: true, id: id, i: i };
      var a = S.a + 2.4 * PI * v * v, r = S.r * (1 - eio(v)); p = [M.cos(a) * r, lp(S.y, 7.5, eio(v)), M.sin(a) * r]; size *= lp(1, .6, v); }
    return { p: p, s: size, id: id, i: i, col: tierRGB(id, T), arriving: u < 1, u: u };
  }

  /* ---------------- SSS sky cracks (cached per plan) ---------------- */
  function cracksFor(P, t0, p) {
    P._cr = P._cr || {}; var key = t0.toFixed(3); if (P._cr[key]) return P._cr[key];
    var r = U.rng(M.floor(t0 * 1000)), d0 = U.nrm(p), out = [];
    for (var c = 0; c < 8; c++) {
      var d = U.nrm(U.add(d0, [(r() - .5) * .1, (r() - .5) * .1, (r() - .5) * .1])), ang = r() * 2 * PI, pts = [U.scl(d, 300)];
      var tA = U.nrm(U.crs(d0, [0, 1, 0.001])), tB = U.crs(d0, tA);
      for (var k = 0; k < 9; k++) { ang += (r() - .5) * 1.1; d = U.nrm(U.add(d, U.add(U.scl(tA, M.cos(ang) * .085), U.scl(tB, M.sin(ang) * .085)))); pts.push(U.scl(d, 300)); }
      out.push(pts);
    }
    return (P._cr[key] = out);
  }

  /* ---------------- cards ---------------- */
  function cardSingle(P, T, st) {
    var t = P.best, c0 = P.T.card, sd = .85 + .12 * t.rank, turns = 2 + t.rank * .5;
    var u = sg(T, c0 + .05, c0 + sd), ang = 360 * turns * (1 - eo(u)), c = M.cos(ang * PI / 180), land = c0 + sd;
    var fl = eio(sg(T, land, land + .6));
    var card = { tier: t.id, x: P.card.x, y: P.card.y + fl * 8 * M.sin((T - land) * 1.4), w: P.card.w, h: P.card.h,
      sx: M.max(.02, M.abs(c)), front: c > 0, s: lp(.12, 1, eob(sg(T, c0 + .05, c0 + .65 + .05 * t.rank), 1.5)) * (1 + .03 * t.rank * bell(T, land, land + .5)),
      rot: lp(-14, 0, eo(u)) + fl * .8 * M.sin((T - land) * .9), a: sg(T, c0 + .02, c0 + .12),
      gemY: -46 * M.sin(PI * sg(T, land, land + .32)) + 8 * M.sin((T - land - .48) * 1.6) * sg(T, land + .48, land + 1.1), squash: 1 - .1 * M.sin(PI * sg(T, land + .32, land + .48)),
      shine: sg(T, land + .05, land + .65), shineA: sg(T, land, land + .1) * (1 - sg(T, land + .6, land + .7)),
      tierS: lp(2.4, 1, eob(sg(T, land + .15, land + .42), 1.6)), tierA: sg(T, land + .15, land + .2),
      nameN: M.max(0, M.floor((T - land - .32) / .04)), starsLit: [], glow: eo(sg(T, c0, c0 + .6)) * (.7 + .1 * M.sin(T * 1.6)), big: true };
    for (var s = 0; s < t.stars; s++) card.starsLit.push(U.cl((T - (land + .55 + s * .08)) / .12));
    st.cards.push(card);
    // rays behind the card, stronger for rare tiers
    st.rays.push({ xy: [960, 540], n: 12 + 4 * t.rank, len: 1500, a: (.07 + .04 * t.rank) * eo(sg(T, c0, c0 + .6)) + .25 * t.rank / 4 * hit(T, land, 2.5), col: t.rank ? t.col : P_.white, rot: T * .12, w: .07 });
    if (t.rank >= 2) burst2d(st, 0, T, land, t, 960, 540);
  }
  function burst2d(st, i, T, t0, t, x, y) {
    var dt = T - t0; if (dt < 0 || dt > 1.6) return;
    var n = M.floor(12 + 14 * t.power);
    for (var k = 0; k < n && k < PT.card[i].length; k++) { var q = PT.card[i][k]; if (dt > q.l) continue; var d = q.v * (1 - M.exp(-3 * dt)) / 3 * (.6 + .2 * t.power);
      st.fx2d.push({ x: x + M.cos(q.a) * d, y: y + M.sin(q.a) * d + 60 * dt * dt, s: q.s * (1 - .5 * dt / q.l), col: k % 3 ? t.col : P_.white, a: 1 - ei(dt / q.l), rot: q.rr * dt, k: q.k }); }
  }
  function cardsMulti(P, T, st) {
    var D = P.T.deal;
    P.pulls.forEach(function (id, i) {
      var t = TI[id], S = P.slots[i], f = P.flips[i], u = sg(T, D + .06 * i, D + .06 * i + .8);
      if (T < D + .06 * i) return;
      var e = eob(u, 1.3), x = lp(960, S.x, eo(u)), y = lp(560, S.y, eo(u)), spin = 360 * (1 - eo(u));
      var antic = sg(T, f.a, f.t) * (1 - sg(T, f.t, f.t + .1)), shake = antic * (2 + 2 * t.rank);
      var fu = sg(T, f.t, f.t + f.d), turns = t.rank >= 3 ? 1.5 : .5, ang = T < f.t ? 180 + spin : 360 * turns * (1 - eio(fu)), c = M.cos(ang * PI / 180);
      var lift = 1 + .08 * antic + (.1 + .04 * t.rank) * bell(T, f.t, f.t + f.d + .3);
      var land = f.t + f.d;
      st.cards.push({ tier: id, x: x + shake * M.sin(T * 47 + i), y: y + shake * M.cos(T * 53 + i) - 14 * antic, w: S.w, h: S.h, sx: M.max(.02, M.abs(c)), front: T >= f.t && c > 0,
        s: lp(.2, 1, e) * lift, rot: lp(-25, 0, eo(u)), a: sg(T, D + .06 * i, D + .06 * i + .1), edge: t.rank ? antic : 0, edgeCol: t.col,
        gemY: -20 * M.sin(PI * sg(T, land, land + .3)), squash: 1 - .08 * M.sin(PI * sg(T, land + .3, land + .42)),
        shine: sg(T, land, land + .5), shineA: sg(T, land - .05, land + .05) * (1 - sg(T, land + .45, land + .55)),
        tierS: lp(1.8 + .2 * t.rank, 1, eob(sg(T, land, land + .25), 1.6)), tierA: sg(T, land, land + .05), nameN: M.max(0, M.floor((T - land - .1) / .03)),
        starsLit: arr(t.stars, function (s) { return U.cl((T - (land + .2 + s * .08)) / .12); }), glow: t.rank ? (.35 + .15 * t.rank) * sg(T, land, land + .3) * (.8 + .2 * M.sin(T * 2 + i)) : 0,
        best: T > P.T.end - 2.8 && t.rank === P.best.rank ? .5 + .5 * M.sin((T - P.T.end) * 3) : 0, big: false, z: t.rank * (T > f.a ? 1 : 0) + (T > f.a && T < land + .8 ? 10 : 0) });
      if (t.rank >= 1) st.rays.push({ xy: [S.x, S.y], n: 8 + 3 * t.rank, len: 260 + 160 * t.rank, a: (.12 + .1 * t.rank) * bell(T, f.t, f.t + f.d + .6 + .3 * t.rank) + (t.rank >= 2 ? .1 * sg(T, land, land + .5) : 0), col: t.col, rot: T * .3 + i, w: .09 });
      if (t.rank >= 1) burst2d(st, i, T, f.t + f.d * .5, t, S.x, S.y);
    });
    st.cards.sort(function (a, b) { return a.z - b.z; });
  }

  /* ================== STATE ================== */
  G.state = function (P, T) {
    var st = { T: T, P: P, K: {}, Li: [], cg: [], sp: [], rings: [], rays: [], cracks: [], cards: [], fx2d: [], flash: 0 }, i;
    var best = P.best, BOOM = P.T.boom, FA = P.T.fall, FE = P.T.fallEnd, multi = P.mode === 'multi';

    /* ---- stars ---- */
    var stars = [], core = null, landed = 0;
    if (!multi) { var sz = sizeSingle(P, T); if (sz > .01) stars.push({ p: starSingle(P, T), s: sz, col: colSingle(P, T), id: P.pulls[0], main: true }); }
    else {
      for (i = 0; i < 10; i++) { var m = starMulti(P, i, T); if (!m) continue; if (m.landed) landed++; else stars.push(m); }
      if (landed && T < BOOM) { var cs = (.45 + .07 * landed); if (T > FE) cs = T < BOOM - .15 ? lp(cs, .5, eio(sg(T, FE, BOOM - .15))) : lp(.5, 2.4 * (.8 + .2 * best.power), ei(sg(T, BOOM - .15, BOOM)));
        core = { p: [0, 7.5 + .12 * M.sin(T * 4), 0], s: cs, col: mix(P_.white, best.rank ? best.col : P_.white, sg(T, FE, BOOM)), main: true }; stars.push(core); }
    }
    var focus;
    if (!multi) focus = stars.length ? stars[0].p : [0, 7.5, 0];
    else if (T < FA) { var nw = null; stars.forEach(function (s) { if (!nw || s.i > nw.i) nw = s; }); focus = nw ? vl([0, 25, 0], nw.p, .35) : [0, 25, 0]; }
    else if (stars.length) { focus = [0, 0, 0]; stars.forEach(function (s) { focus = U.add(focus, s.p); }); focus = U.scl(focus, 1 / stars.length); }
    else focus = [0, 7.5, 0];
    st.starPos = focus;

    /* ---- camera ---- */
    var c = P.cam(T, st), pos = [M.sin(c.th) * c.R, c.H, M.cos(c.th) * c.R], tg = vl([0, c.TY, 0], focus, c.WS);
    var fw = U.nrm(U.sub(tg, pos)), rt = U.nrm(U.crs(fw, [0, 1, 0])), up = U.crs(rt, fw);
    st.cam = { pos: pos, fw: fw, rt: rt, up: up, F: c.F };
    var A = 5 * eio(sg(T, FA + .3, FE)) * (1 - sg(T, FE + .05, FE + .25));
    P.hits.forEach(function (h) { A += h.a * hit(T, h.t, h.k); });
    st.shake = [A * (M.sin(T * 37.1) + .5 * M.sin(T * 61.7 + 1)) / 1.5, A * (M.sin(T * 41.3 + 2) + .5 * M.sin(T * 53.9)) / 1.5, .03 * M.sin(T * 1.3) * sg(T, FA, FE) * (1 - sg(T, FE, BOOM))];
    st.dim = multi ? .55 * eio(sg(T, BOOM + .5, P.T.deal + .9)) : .42 * eio(sg(T, BOOM + .6, BOOM + 1.7));
    st.wash = T > BOOM ? .42 * M.exp(-(T - BOOM) * 4.5) : 0;

    /* ---- summoning feathers: 1 (single) or 10 in a ring (multi) ---- */
    st.fe = [];
    var nf = multi ? 10 : 1;
    for (i = 0; i < 10; i++) {
      if (i >= nf) { st.fe.push(null); continue; }
      var d0 = multi ? i * .07 : 0, fu = sg(T, .15 + d0, 1.25 + d0), fs = lp(1, 0, ei(sg(T, 1.25 + d0, 2.1 + d0 * .5)));
      var ra = multi ? lp(2.6, 1.1, eio(fu)) : 0, aa = i * 2 * PI / 10 + T * .5;
      st.fe.push(fs > .01 ? { p: [M.cos(aa) * ra + .4 * M.sin(T * 2.1 + i) * (1 - fu), lp(10.5 + (multi ? (i % 3) * .6 : 0), 4.25, eio(fu)), M.sin(aa) * ra + .3 * M.cos(T * 1.7 + i) * (1 - fu)], ry: T * .9 + i, rz: .3 * M.sin(T * 1.6 + i) * (1 - fu) + .08 + (multi ? .35 : 0), s: fs * (multi ? .8 : 1) } : null);
    }
    st.K.fe = [mix(P_.white, P_.accent, sg(T, 1.15, 1.8)), .15 + sg(T, 1.1, 1.8) * .85];

    /* ---- crystal, orbiting shards, rune loader ---- */
    var ch = sg(T, 2.4, 4.2);
    st.cry = { p: [0, 5.75 + .25 * M.sin(T * 1.4) + 1.1 * eio(sg(T, P.eru, P.eru + .7)), 0], ry: .5 * T + 2.5 * (T - 2.4) * ch + 3 * (T - FA) * sg(T, FA, FE), s: 1 + .15 * ch };
    st.K.cry = [P_.accent, .3 + .5 * ch + .4 * hit(T, BOOM, 2)];
    st.sh = [];
    for (i = 0; i < 8; i++) { var rr = 6.6 - 1.1 * eio(ch) + 3.2 * eio(sg(T, FA + .4, P.eru)) + 3 * eo(sg(T, BOOM, BOOM + 1)), ya = 2.4 + 1.6 * eio(ch) + .4 * M.sin(T * 1.3 + i) + 2 * sg(T, FA + .4, P.eru), an = i * PI / 4 + .3 * T + .6 * (T - 2.4) * ch + .9 * (T - FA) * sg(T, FA, FE);
      st.sh.push({ p: [M.cos(an) * rr, ya, M.sin(an) * rr], ry: T * (1 + i * .2), rx: T * (.6 + i * .13), s: 1 }); }
    for (i = 0; i < 24; i++) { var ti = 2.45 + i * .068, on = sg(T, ti, ti + .12), rc = mix(P_.accent, P_.white, .7 * (1 - sg(T, ti + .05, ti + .45)) * (T > ti ? 1 : 0));
      if (T > P.eru) rc = mix(rc, flameCol(T * 1.4, i / 6, P.eru), sg(T, P.eru, P.eru + .4));
      if (T > BOOM) rc = mix(rc, best.rank ? best.col : P_.white, .8 * M.exp(-(T - BOOM) * 2));
      st.K['r' + i] = [rc, on * .95]; }

    /* ---- lights and flames ---- */
    st.Li.push({ p: st.cry.p, c: P_.accent, I: .55 + 1.1 * ch, g: 2.6 });
    var ER = P.eru, endF = multi ? P.T.deal : BOOM + .6;
    var bf = .55 * eo(sg(T, 1.2, 1.7)) + .35 * eo(sg(T, 2.4, 4.0)) - .25 * sg(T, 4.4, 5.2) + (T > ER ? .9 * eob(sg(T, ER, ER + .5), 1.8) : 0) + .5 * hit(T, BOOM, 2) - .45 * sg(T, endF, endF + 1.3);
    var bc = T < ER ? P_.accent : mix(P_.accent, flameCol(T, 0, ER), sg(T, ER, ER + .3));
    if (T > BOOM && best.rank) bc = mix(bc, best.col, sg(T, BOOM, BOOM + .3));
    st.K.bowl = [bc, U.cl(bf) * .9];
    if (bf > .02) {
      st.Li.push({ p: [0, 4.6, 0], c: bc, I: bf * 2.2, g: 2 });
      if (T < ER) st.sp.push({ k: 'flame', p: [0, 3.7, 0], s: bf, c: P_.accent, sd: 0 });
      else { for (i = 0; i < 4; i++) { var a2 = i * PI / 2 + T * .6; st.sp.push({ k: 'flame', p: [M.cos(a2) * .9, 3.75, M.sin(a2) * .9], s: bf * .75, c: P_[G.FLAMES[i]], sd: i + 1 }); } st.sp.push({ k: 'flame', p: [0, 3.7, 0], s: bf * 1.05, c: mix(bc, P_.white, .35), sd: 7 }); }
    }
    for (i = 0; i < 4; i++) {
      var IG = P.ign[i], PL = G.PILLARS[i];
      if (T <= IG) { st.K['c' + i] = [P_.obs2, 0]; continue; }
      var ps = .62 * eob(sg(T, IG, IG + .45), 2.4) + .3 * hit(T, BOOM, 2), fc = P_[G.FLAMES[i]];
      st.sp.push({ k: 'flame', p: PL, s: ps, c: fc, sd: i * 3 + 2 }); st.Li.push({ p: U.add(PL, [0, .9, 0]), c: fc, I: ps * 2.6, g: 1.6 }); st.K['c' + i] = [fc, .85];
      st.rings.push({ c: [PL[0], .55, PL[2]], r: 4.2 * eo(sg(T, IG, IG + .8)), a: 1 - sg(T, IG, IG + .8), w: 9, col: fc });
      PT.ign[i].forEach(function (q) { var t = T - IG; if (t > q.l) return; var d = q.v * (1 - M.exp(-2.5 * t)) / 2.5; st.sp.push({ k: 'dia', p: [PL[0] + q.d[0] * d, PL[1] + .6 + q.d[1] * d - 3 * t * t, PL[2] + q.d[2] * d], s: .16, c: mix(fc, P_.white, .4), a: 1 - t / q.l, r: t * 9 }); });
    }
    if (T > ER) { st.rings.push({ c: [0, .55, 0], r: 11 * eo(sg(T, ER, ER + 1)), a: 1 - sg(T, ER, ER + 1), w: 12, col: flameCol(T, 0, ER) });
      PT.eru.forEach(function (q) { var t = T - ER; if (t > q.l) return; var d = q.v * (1 - M.exp(-2 * t)) / 2; st.sp.push({ k: 'dia', p: [q.d[0] * d, 4 + q.d[1] * d - 3.5 * t * t, q.d[2] * d], s: .2, c: P_[q.c], a: 1 - t / q.l, r: t * 7 }); }); }
    if (T > 4.05) st.rings.push({ c: [0, .55, 0], r: 7.6 * eo(sg(T, 4.05, 4.8)), a: .8 * (1 - sg(T, 4.05, 4.8)), w: 8, col: P_.accent });

    /* ---- the stars themselves ---- */
    var sI = 0;
    stars.forEach(function (s, k) {
      var tw = M.sin(T * 2.2 + k) * .06;
      st.sp.push({ k: 'star', p: s.p, s: s.s * (1.25 + tw), c: mix(s.col, P_.white, .25), a: 1, r: T * .9 + .3 * M.sin(T * 1.1 + k) + k });
      st.sp.push({ k: 'star', p: s.p, s: s.s * .62, c: mix(s.col, P_.white, .6), a: .95, r: -T * 1.3 + PI / 4 + k });
      var I = s.main ? (T < FA ? .7 * s.s : T < FE ? 1.9 : T < BOOM - .15 ? lp(1.9, 3.8, sg(T, FE, BOOM - .15)) : lp(3.8, 6, sg(T, BOOM - .15, BOOM))) : .9 * s.s;
      (s.main || multi ? st.Li : st.cg).push({ p: s.p, c: s.col, I: I, g: 3 + s.s });
    });
    if (T >= BOOM) st.Li.push({ p: [0, 7.5, 0], c: best.rank ? mix(best.col, P_.white, .5) : P_.white, I: (8 + 2 * best.power) * M.exp(-(T - BOOM) * 2.4), g: 3.4 });
    // trails
    if (!multi && stars.length && T > 4.6) for (i = 1; i <= 10; i++) { var tk = T - i * .045; if (tk < 4.45) break; st.sp.push({ k: 'dia', p: starSingle(P, tk), s: stars[0].s * .32 * (1 - i / 11), c: stars[0].col, a: .55 * (1 - i / 11) }); }
    if (multi) stars.forEach(function (s) { if (s.i == null) return; var arriving = s.arriving || T > P.fallWin[s.i][0]; if (!arriving) return;
      for (var j = 1; j <= 8; j++) { var q = starMulti(P, s.i, T - j * .04); if (!q || q.landed || T - j * .04 < P.spawn[s.i]) break; st.sp.push({ k: 'dia', p: q.p, s: s.s * .3 * (1 - j / 9), c: s.col, a: .6 * (1 - j / 9) }); } });
    // ethereal dust shed by the single star
    if (!multi) PT.dust.forEach(function (q) { var b = 4.45 + q.b * (P.T.fall + 1.4 - 4.45), t = T - b; if (t < 0 || t > q.l) return; var o = U.add(starSingle(P, b), q.o); st.sp.push({ k: 'dia', p: [o[0] + .3 * M.sin(t * 2 + q.v * 9), o[1] - q.v * t, o[2]], s: .09, c: P_.white, a: M.sin(PI * t / q.l) * .9, r: t * 3 }); });
    // single: 12 small companion stars born in the wake of the star, whirling around the altar
    if (!multi) PT.comp.forEach(function (q, k) {
      var s0 = P.comp[k]; if (T < s0 || (T > BOOM && T < BOOM + .08)) return;
      var r = q.r * (1 + .35 * eo(sg(T, BOOM, BOOM + 1.2))), a = q.p + q.w * T, h = q.h + .45 * M.sin(T * 1.7 + q.p) + 1.2 * eo(sg(T, BOOM, BOOM + 1.2));
      var p = vl(starSingle(P, s0), [M.cos(a) * r, h, M.sin(a) * r], eo(sg(T, s0, s0 + .65)));
      p = vl(p, starSingle(P, T), eio(sg(T, FE + .1, BOOM - .05)) * (1 - eo(sg(T, BOOM, BOOM + 1))));
      var z = q.z * eo(sg(T, s0, s0 + .4)) * (1 + .6 * eio(sg(T, FE + .1, BOOM - .1))), cc = mix(P_.white, P_[G.FLAMES[k % 4]], .25);
      if (best.rank) cc = mix(cc, best.col, .35 * sg(T, P.beats.length ? P.beats[P.beats.length - 1].t : 0, BOOM));
      st.cg.push({ p: p, c: mix(cc, P_.white, .3), I: z * 2.2, g: z * 3 });
      st.sp.push({ k: 'star', p: p, s: z * (1 + .15 * M.sin(T * 2 + k)), c: cc, a: 1, r: T * (1.2 + k * .1) });
    });
    // single: beats (colour changes of the star)
    P.beats.forEach(function (b, k) {
      if (T < b.t || T > b.t + 1) return; var bt = TI[b.tier], sp = starSingle(P, b.t), u = sg(T, b.t, b.t + .8);
      st.rings.push({ c: sp, r: (3 + 2 * k) * eo(u), a: 1 - u, w: 8 + 3 * k, col: bt.col });
      st.rings.push({ c: [0, .55, 0], r: (6 + 3 * k) * eo(u), a: .6 * (1 - u), w: 6, col: bt.col });
      st.flash = M.max(st.flash, (.1 + .06 * k) * flashShape(T - b.t, .25));
      if (b.tier === 'SSS') st.cracks.push({ pts: cracksFor(P, b.t, sp), prog: eo(sg(T, b.t, b.t + .6)), a: 1, col: bt.col });
    });
    if (!multi && P.beats.length && P.beats[P.beats.length - 1].tier === 'SSS') { var bt0 = P.beats[P.beats.length - 1].t; if (T > bt0 + 1) st.cracks.push({ pts: cracksFor(P, bt0, starSingle(P, bt0)), prog: 1, a: 1 - sg(T, BOOM, BOOM + .8), col: TI.SSS.col }); }
    // multi: arrival of each star in the sky, stronger with rarity
    if (multi) P.pulls.forEach(function (id, k) {
      var t = TI[id], s0 = P.spawn[k], ta = s0 + t.spawn * .7, S = slot(k, ta).p; if (T < s0) return;
      var u = sg(T, ta - .05, ta + .7 + .2 * t.rank);
      if (u > 0 && u < 1) { st.rings.push({ c: S, r: (1.5 + 1.6 * t.rank) * eo(u), a: (1 - u) * (.6 + .1 * t.rank), w: 5 + 3 * t.rank, col: t.rank ? t.col : P_.white });
        if (t.rank >= 2) st.rings.push({ c: [0, 25, 0], r: lp(10, 10 + 4 * t.rank, eo(u)), a: .5 * (1 - u), w: 4 + 2 * t.rank, col: t.col }); }
      PT.spawn[k].forEach(function (q, j) { if (j >= 8 + 6 * t.rank) return; var dt = T - ta; if (dt < 0 || dt > q.l) return; var d = q.v * (.6 + .3 * t.power) * (1 - M.exp(-3 * dt)) / 3; st.sp.push({ k: 'dia', p: U.add(slot(k, T).p, U.scl(q.d, d)), s: .12 + .03 * t.rank, c: j % 2 ? t.col : P_.white, a: 1 - dt / q.l, r: dt * 6 }); });
      if (t.rank >= 2) st.flash = M.max(st.flash, (.08 + .07 * (t.rank - 1)) * flashShape(T - ta, .3));
      if (t.rank >= 3) st.rays.push({ p: S, n: 10 + 4 * t.rank, len: 900, a: .45 * bell(T, ta - .05, ta + .9), col: t.col, rot: T * .4 + k, w: .06 });
      if (id === 'SSS') st.cracks.push({ pts: cracksFor(P, ta, S), prog: eo(sg(T, ta, ta + .6)), a: 1 - sg(T, BOOM, BOOM + .8), col: t.col });
    });
    // feathers' embers, rune motes
    PT.ember.forEach(function (q, k) { if (!multi && k > 25) return; var t = T - (1.25 + q.b * (multi ? 1.6 : 1.7)); if (t < 0 || t > q.l) return; st.sp.push({ k: 'dia', p: [M.cos(q.a + t * 2) * q.r * (1 + t), 4.3 + q.v * t, M.sin(q.a + t * 2) * q.r * (1 + t)], s: .11, c: P_[q.c], a: 1 - t / q.l, r: t * 5 }); });
    PT.mote.forEach(function (q) { var t = T - q.b; if (t < 0 || t > q.l) return; var u2 = eio(t / q.l), a = q.a + u2 * 2.4, r = lp(6.5, .4, u2); st.sp.push({ k: 'dia', p: [M.cos(a) * r, lp(.3, 5.6, u2) + M.sin(u2 * PI) * 1.2, M.sin(a) * r], s: .13, c: P_[q.c], a: M.sin(PI * t / q.l) }); });
    // the burst
    if (T > BOOM) {
      var bcols = [P_.white, best.rank ? best.col : P_.accent, P_.blue, P_.red, P_.green, best.rank ? best.col : P_.white], nb = M.min(PT.boom.length, M.floor(60 * (.8 + .2 * best.power)));
      for (i = 0; i < nb; i++) { var q = PT.boom[i], t = T - BOOM; if (t > q.l) continue; var d = q.v * (.85 + .15 * best.power) * (1 - M.exp(-2.2 * t)) / 2.2; st.sp.push({ k: 'tri', p: [q.d[0] * d, 7.5 + q.d[1] * d - 1.5 * t * t, q.d[2] * d], s: q.s * (1 - .5 * t / q.l), c: bcols[q.ci], a: 1 - ei(t / q.l), r: q.rr * t }); }
      st.rings.push({ c: [0, .55, 0], r: (24 + 4 * best.rank) * eo(sg(T, BOOM, BOOM + 1.3)), a: 1 - sg(T, BOOM, BOOM + 1.3), w: 16, col: P_.white });
      st.rings.push({ c: [0, 7.5, 0], r: (14 + 3 * best.rank) * eo(sg(T, BOOM + .06, BOOM + 1)), a: .8 * (1 - sg(T, BOOM + .06, BOOM + 1)), w: 10, col: best.rank ? best.col : P_.accent });
      if (best.rank >= 3) st.rings.push({ c: [0, 7.5, 0], r: 30 * eo(sg(T, BOOM + .15, BOOM + 1.4)), a: .7 * (1 - sg(T, BOOM + .15, BOOM + 1.4)), w: 14, col: P_.white });
      PT.glint.forEach(function (q) { var t = T - BOOM - .3; if (t < 0) return; var lt = t % q.l; if (M.floor(t / q.l) > 2) return; st.sp.push({ k: 'dia', p: [M.cos(q.a + t * .2) * q.r, 7.5 + q.y - q.v * lt, M.sin(q.a + t * .2) * q.r], s: .12, c: P_.white, a: M.sin(PI * lt / q.l) * .8 * eo(U.cl(t / .5)), r: t }); });
    }
    st.rays.push({ p: [0, 7.5, 0], n: 16 + 4 * best.rank, len: 1700 * eo(sg(T, BOOM, BOOM + .35)), a: T > BOOM ? .5 * (1 - sg(T, BOOM + .1, BOOM + 1.6)) : 0, col: best.rank ? mix(best.col, P_.white, .4) : P_.white, rot: T * .22, w: .06, seed: 9 });
    st.flash = M.max(st.flash, (best.rank >= 4 ? .85 : .7) * flashShape(T - BOOM, best.rank >= 4 ? .45 : .4));
    // charge beam
    st.beam = T > 3.85 && T < 5.1 ? { y: lp(4, 80, eo(sg(T, 3.85, 4.2))), w: (1 - sg(T, 4.5, 5.1)) * eo(sg(T, 3.85, 3.95)) } : null;

    /* ---- cards ---- */
    if (!multi && T > P.T.card) cardSingle(P, T, st);
    if (multi && T > P.T.deal) { cardsMulti(P, T, st);
      P.flips.forEach(function (f, i) { var t = TI[P.pulls[i]]; if (t.rank >= 2) st.flash = M.max(st.flash, (.12 + .12 * (t.rank - 2)) * flashShape(T - (f.t + f.d * .5), .3)); }); }
    return st;
  };
  function flashShape(dt, d) { if (dt < -.04 || dt > d) return 0; return dt < 0 ? (dt + .04) / .04 : 1 - ei(dt / d); }
})(globalThis.GM);
