/* timeline.js : turns a pull list into a PLAN = every time anchor of the animation,
   the camera curves, the screen-shake hits and an event list (for sounds / the Java port).

   G.plan(['SS'])                      -> single pull, choreography scaled by its rarity
   G.plan(['B','B',...10 tiers])       -> ×10 pull, stars spawn in pull order, cards flip in pull order

   The plan is plain data: G.exportPlan(plan) gives the JSON written next to each video. */
(function (G) {
  var U = G.U, T_ = G.TIERS, M = Math;

  /* ---------------- camera of the validated single-B film (reference times) ---------------- */
  var REF = [0, 2.2, 4.4, 5.9, 8.9, 9.6, 10.4, 14.4]; // altar, charge, star, fall, fallEnd, boom, card, end
  var CAM_B = {
    R:  [[0, 30], [1.3, 23], [2.2, 21], [3.4, 17], [4.4, 15], [5.9, 15], [7.0, 19], [8.2, 24], [8.9, 21], [9.55, 13.5], [10.4, 16], [11.5, 18], [14.4, 20]],
    H:  [[0, 12], [1.3, 8.5], [2.2, 7], [3.4, 5], [4.4, 3], [5.9, 2.6], [7.0, 4.5], [8.2, 7.5], [8.9, 6.5], [9.55, 5.4], [10.4, 6.2], [14.4, 7.8]],
    TY: [[0, 3.2], [2.2, 3.6], [3.7, 4.2], [4.4, 8.5], [5.9, 9], [8.9, 6], [9.6, 7.4], [10.4, 7.2], [14.4, 6]],
    FL: [[0, 1500], [2.2, 1450], [4.4, 1250], [5.9, 1150], [8.9, 1250], [9.55, 1650], [10.4, 1400], [14.4, 1480]],
    WS: [[0, 0], [4.3, 0], [5.2, .7], [5.9, .75], [7.5, .55], [8.9, .35], [9.6, .1], [10.4, 0], [14.4, 0]],
    OM: [[0, .55], [1.2, .75], [2.2, .9], [3.4, 1.25], [4.4, .95], [5.2, .45], [5.9, .6], [7.2, 1.5], [8.6, 2.1], [9.2, .9], [9.6, .35], [10, .6], [10.6, .35], [14.4, .22]]
  };

  function hits(P) { // screen shake impulses {t, a(px), k(decay)}
    var h = []; P.ign.forEach(function (t) { h.push({ t: t, a: 7, k: 6 }); });
    h.push({ t: P.eru, a: 11, k: 5 }); h.push({ t: P.T.boom, a: 16 + 6 * P.best.power, k: 4 });
    return h;
  }

  function single(id) {
    var t = T_[id], Ld = 3 + t.fallExtra, D0 = 5.9, D1 = D0 + Ld, BOOM = D1 + t.hold, CARD = BOOM + .8, END = CARD + t.cardDur;
    var P = { mode: 'single', pulls: [id], best: t, len: END, Ld: Ld,
      T: { altar: 0, charge: 2.2, star: 4.4, fall: D0, fallEnd: D1, boom: BOOM, card: CARD, end: END } };
    P.ign = [.15, .32, .48, .65].map(function (u) { return D0 + u * Ld; });
    P.eru = D0 + .82 * Ld;
    P.beats = t.chain.map(function (c, k) { return { t: D0 + Ld * (.1 + .72 * (k + 1) / (t.chain.length + 1)), tier: c }; });
    P.comp = []; for (var i = 0; i < 12; i++) P.comp.push(D0 + Ld * (.05 + i * .063));
    P.hits = hits(P); P.beats.forEach(function (b, k) { P.hits.push({ t: b.t, a: 5 + 3 * k, k: 7 }); });
    var B = [0, 2.2, 4.4, D0, D1, BOOM, CARD, END];
    P.cam = function (T, st) {
      var Tr = U.remap(T, B, REF), K = CAM_B;
      return { R: U.key(K.R, Tr), H: U.key(K.H, Tr), TY: U.key(K.TY, Tr), F: U.key(K.FL, Tr), WS: U.cl(U.key(K.WS, Tr)),
        th: -.95 + U.integ(K.OM, Tr) + t.fallExtra * 1.15 * U.eio(U.sg(T, D0, D1)), focus: st.starPos };
    };
    P.card = { x: 960, y: 540, w: 520, h: 700 };
    P.events = ev(P);
    return P;
  }

  function multi(pulls) {
    var best = G.best(pulls), s = 4.6, sp = [];
    pulls.forEach(function (id) { sp.push(s); s += T_[id].spawn; });
    var sEnd = s, FALL = sEnd + 1.0, FD = 3.4, FE = FALL + FD, BOOM = FE + .6 + .2 * best.rank, DEAL = BOOM + .65;
    var flips = [], f = DEAL + 1.5;
    pulls.forEach(function (id) { var t = T_[id], pre = .25 * t.rank; flips.push({ a: f, t: f + pre, d: t.flip }); f += pre + t.gap; });
    var END = f + 2.8;
    var P = { mode: 'multi', pulls: pulls.slice(), best: best, len: END, spawn: sp, FD: FD,
      T: { altar: 0, charge: 2.2, star: 4.6, spawnEnd: sEnd, fall: FALL, fallEnd: FE, boom: BOOM, deal: DEAL, flips: flips[0].a, end: END }, flips: flips };
    P.fallWin = pulls.map(function (id, i) { return [FALL + .09 * i, FALL + .09 * i + 2.6]; });
    P.ign = [.2, .36, .52, .68].map(function (u) { return FALL + u * FD; });
    P.eru = FALL + .84 * FD;
    P.beats = [];
    P.comp = [];
    P.hits = hits(P);
    pulls.forEach(function (id, i) { var t = T_[id]; if (t.rank) P.hits.push({ t: sp[i] + t.spawn * .7, a: 3 + 4 * t.rank, k: 5 }); if (t.rank > 1) P.hits.push({ t: flips[i].t + flips[i].d * .5, a: 2 + 3 * t.rank, k: 6 }); });
    var K = {
      R:  [[0, 30], [1.3, 23], [2.2, 21], [3.4, 17], [4.4, 15], [5.0, 14], [sEnd, 13], [FALL, 14], [FALL + FD * .4, 19], [FALL + FD * .8, 23], [FE, 20], [BOOM, 13.5], [DEAL, 17], [END, 18.5]],
      H:  [[0, 12], [1.3, 8.5], [2.2, 7], [3.4, 5], [4.4, 3], [5.0, 2.4], [sEnd, 2.2], [FALL, 2.6], [FALL + FD * .4, 5], [FALL + FD * .8, 7.5], [FE, 6.5], [BOOM, 5.4], [DEAL, 6.4], [END, 7]],
      TY: [[0, 3.2], [2.2, 3.6], [3.7, 4.2], [4.4, 8.5], [sEnd, 9], [FALL, 9], [FE, 6], [BOOM, 7.4], [DEAL, 7], [END, 6.5]],
      FL: [[0, 1500], [2.2, 1450], [4.4, 1250], [5.0, 1100], [sEnd, 1050], [FALL, 1150], [FE, 1250], [BOOM - .05, 1650], [DEAL, 1400], [END, 1450]],
      WS: [[0, 0], [4.3, 0], [5.0, .8], [sEnd, .8], [FALL, .78], [FALL + FD * .55, .5], [FE, .3], [BOOM, .1], [DEAL, 0], [END, 0]],
      OM: [[0, .55], [1.2, .75], [2.2, .9], [3.4, 1.25], [4.4, .95], [5.2, .5], [sEnd, .42], [FALL, .6], [FALL + FD * .45, 1.5], [FE - .3, 2.1], [FE + .2, .9], [BOOM, .35], [BOOM + .4, .6], [DEAL + .6, .25], [END, .15]]
    };
    P.cam = function (T) { return { R: U.key(K.R, T), H: U.key(K.H, T), TY: U.key(K.TY, T), F: U.key(K.FL, T), WS: U.cl(U.key(K.WS, T)), th: -.95 + U.integ(K.OM, T), focus: null }; };
    // 5 x 2 grid of cards in front of the player
    P.slots = pulls.map(function (id, i) { var c = i % 5, r = M.floor(i / 5); return { x: 263 + 125 + c * 286, y: 170 + 170 + r * 380, w: 250, h: 340 }; });
    P.events = ev(P);
    return P;
  }

  /** flat event list, sorted, for sounds / gameplay hooks (ids follow SOUND_DESIGN.md naming) */
  function ev(P) {
    var E = [], T = P.T;
    E.push({ t: 0, id: 'gacha.launch' }); E.push({ t: 1.25, id: 'gacha.feather.burn' }); E.push({ t: 2.45, id: 'gacha.rune.charge' }); E.push({ t: 4.05, id: 'gacha.beam' });
    if (P.mode === 'single') { E.push({ t: 4.4, id: 'gacha.star.appear', tier: P.pulls[0] }); P.beats.forEach(function (b) { E.push({ t: b.t, id: 'gacha.escalate.' + b.tier.toLowerCase() }); }); }
    else P.pulls.forEach(function (id, i) { E.push({ t: P.spawn[i], id: 'gacha.star.spawn.' + id.toLowerCase(), index: i }); });
    E.push({ t: T.fall, id: 'gacha.star.fall' });
    P.ign.forEach(function (t, i) { E.push({ t: t, id: 'gacha.flame.ignite', flame: G.FLAMES[i] }); });
    E.push({ t: P.eru, id: 'gacha.flame.erupt' }); E.push({ t: T.boom, id: 'gacha.impact.' + P.best.id.toLowerCase() });
    if (P.mode === 'single') { E.push({ t: T.card, id: 'gacha.card.spin' }); E.push({ t: T.card + .85, id: 'gacha.reveal.' + P.pulls[0].toLowerCase() }); for (var s = 0; s < P.best.stars; s++) E.push({ t: T.card + 1.35 + s * .08, id: 'gacha.star' }); }
    else { E.push({ t: T.deal, id: 'gacha.card.deal' }); P.flips.forEach(function (f, i) { E.push({ t: f.t, id: 'gacha.reveal.' + P.pulls[i].toLowerCase(), index: i }); }); }
    E.push({ t: P.len, id: 'end' });
    E.sort(function (a, b) { return a.t - b.t; }); E.forEach(function (e) { e.t = +e.t.toFixed(3); });
    return E;
  }

  G.plan = function (pulls) { return pulls.length === 1 ? single(pulls[0]) : multi(pulls); };
  G.exportPlan = function (P, name) {
    var o = { name: name, mode: P.mode, pulls: P.pulls, best: P.best.id, length: +P.len.toFixed(3), fps_preview: 30, anchors: {}, flames: G.FLAMES, events: P.events };
    for (var k in P.T) o.anchors[k] = +(+P.T[k]).toFixed(3);
    if (P.mode === 'multi') { o.spawn = P.spawn.map(function (v) { return +v.toFixed(3); }); o.flips = P.flips.map(function (f, i) { return { index: i, tier: P.pulls[i], anticipation: +f.a.toFixed(3), flip: +f.t.toFixed(3), duration: f.d }; }); o.slots = P.slots; }
    else { o.beats = P.beats.map(function (b) { return { t: +b.t.toFixed(3), tier: b.tier }; }); o.card = P.card; }
    return o;
  };
})(globalThis.GM);
