import sys,glob,os
from PIL import Image,ImageDraw
name=sys.argv[1];ts=sys.argv[2].split(',')
W,H=640,360;cols=4;rows=(len(ts)+cols-1)//cols;s=Image.new('RGB',(W*cols,H*rows))
d=ImageDraw.Draw(s)
for i,t in enumerate(ts):
  im=Image.open(f'out/{name}_{float(t) if "." in t else int(t) if t.isdigit() else t}.jpg'.replace('.0.jpg','.jpg')) if False else None
  for c in [f'out/{name}_{t}.jpg']:
    if os.path.exists(c): im=Image.open(c)
  if im: s.paste(im.resize((W,H)),((i%cols)*W,(i//cols)*H)); d.text(((i%cols)*W+6,(i//cols)*H+6),t,fill=(255,255,0))
s.save(f'out/sheet_{name}.jpg',quality=85)
