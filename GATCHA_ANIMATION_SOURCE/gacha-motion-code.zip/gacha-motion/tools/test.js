const fs=require('fs');['core','tiers','altar','timeline','state','renderer','anims'].forEach(f=>eval(fs.readFileSync(__dirname+'/../src/'+f+'.js','utf8')));
for(const k in GM.ANIMS){const P=GM.plan(GM.ANIMS[k]);let mx=0;const t0=Date.now();let n=0;
 for(let T=0;T<=P.len;T+=1/15){const st=GM.state(P,T);const fr=GM.project(st);mx=Math.max(mx,fr.items.length);n++;}
 console.log(k,P.len.toFixed(2),'maxItems',mx,'ms',((Date.now()-t0)/n).toFixed(1), JSON.stringify(P.T));}
