/* node tools/render.js [anim ...]  -> out/<anim>.mp4 (1920x1080, 30 fps, H.264) + out/<anim>.timeline.json
   options: --fps=30 --hud (burn timecode) --only-frames=0,5.2,9 (stills, no video) */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const { spawn } = require('child_process');
const root = path.resolve(__dirname, '..'), out = path.join(root, 'out'); fs.mkdirSync(out, { recursive: true });
const args = process.argv.slice(2), opt = Object.fromEntries(args.filter(a => a.startsWith('--')).map(a => { const [k, v] = a.slice(2).split('='); return [k, v ?? true]; }));
const fps = +(opt.fps || 30);
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  await page.goto('file://' + path.join(root, 'player.html') + '?render=1');
  const names = args.filter(a => !a.startsWith('--')); const all = await page.evaluate(() => Object.keys(GM.ANIMS));
  for (const name of names.length ? names : all) {
    await page.evaluate(([n, h]) => { window.__n = n; const p = GM.ANIMS[n]; window.__plan = GM.plan(p); window.__ctx = document.getElementById('c').getContext('2d'); window.__hud = h ? n + ' [' + p.join(' ') + ']' : null; }, [name, !!opt.hud]);
    const meta = await page.evaluate(() => GM.exportPlan(window.__plan, window.__n));
    fs.writeFileSync(path.join(out, name + '.timeline.json'), JSON.stringify(meta, null, 2));
    const grab = async (t) => { const b64 = await page.evaluate((t) => { GM.drawFrame(window.__ctx, window.__plan, t, { hud: window.__hud }); return document.getElementById('c').toDataURL('image/jpeg', .92).slice(23); }, t); return Buffer.from(b64, 'base64'); };
    if (opt['only-frames']) { for (const t of String(opt['only-frames']).split(',').map(Number)) fs.writeFileSync(path.join(out, `${name}_${t}.jpg`), await grab(t)); continue; }
    const n = Math.ceil(meta.length * fps) + 1, file = path.join(out, name + '.mp4'), t0 = Date.now();
    const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', file]);
    for (let i = 0; i < n; i++) { const buf = await grab(i / fps); if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r)); }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
    console.log(name, meta.length.toFixed(2) + 's', n, 'frames', ((Date.now() - t0) / 1000).toFixed(1) + 's');
  }
  await browser.close();
})();
