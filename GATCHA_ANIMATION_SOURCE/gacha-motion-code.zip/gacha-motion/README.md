# Gacha motion : prévisualisation des invocations de l'autel draconique

Prototype hors jeu des animations d'invocation (single par rareté et multi ×10).
Tout est du code : pas de vidéo source, pas d'asset. Chaque image est une
**fonction pure du temps** : `state(plan, T)` ne dépend jamais de l'image précédente.
Le même code peut donc tourner **en live** (n'importe quelle liste de tirages)
ou être **pré-rendu** en MP4.

## Contenu

| Fichier | Rôle |
| --- | --- |
| `src/core.js` | maths, easings, PRNG déterministe, courbes de clés (Hermite), intégrale de vitesse d'orbite |
| `src/tiers.js` | **palette + réglages par rareté** (couleurs, durées, puissance). Le fichier à retoucher en premier |
| `src/altar.js` | la scène low poly : chaque pièce (`PART ...`) est un prisme, cône ou bipyramide avec rayons, hauteurs et positions explicites. 1 unité = 1 bloc |
| `src/timeline.js` | `GM.plan(pulls)` : transforme une liste de tirages en ancres de temps, courbes caméra, secousses et **liste d'événements** |
| `src/state.js` | l'état du monde à l'instant T : caméra, lumières, flammes, étoiles, particules, anneaux, rayons, fissures, flash, cartes |
| `src/renderer.js` | projection perspective, tri du peintre, ombrage plat, halos additifs, peinture canvas 1920×1080 |
| `src/cards.js` | cartes 2D + police pixel 5×7 (majuscules) |
| `src/anims.js` | les listes de tirages rendues (`single_b` … `multi_x10_double_sss`) |
| `player.html` | lecteur live : choix d'animation, scrub, lecture, bouton « Random ×10 » / « Random ×1 » |
| `tools/render.js` | rendu MP4 30 fps (Playwright + ffmpeg) et JSON de timeline |
| `out/*.mp4` | vidéos 1920×1080, 30 i/s, H.264, sans son |
| `out/*.timeline.json` | ancres + événements horodatés de chaque vidéo (pour le son et le portage Java) |

## Lancer

```bash
npm i playwright        # Chromium inclus
node tools/render.js                       # toutes les animations -> out/
node tools/render.js single_ss --hud       # une seule, avec timecode incrusté
node tools/render.js multi_x10 --only-frames=10,18.5,30   # images fixes
open player.html?anim=multi_x10            # ou ?pulls=B,A,S,SS,SSS,B,B,B,B,SSS
```

## Découpage

### Single (1 plume)

| Temps (B) | Phase |
| --- | --- |
| 0 – 2,2 | **Autel** : la caméra plonge, la plume descend et se consume (braises violettes) |
| 2,2 – 4,4 | **Charge** : 24 runes s'allument une à une (le chargeur), le cristal accélère, faisceau vers le ciel à 4,05 |
| 4,4 – 5,9 | **Étoile** : pure, lente, éthérée, la caméra la suit |
| 5,9 – `fallEnd` | **Chute** : spirale autour de l'autel, 12 petites étoiles dans son sillage, flammes bleue, rouge, blanche, verte puis éruption de la vasque. **Escalade** : un battement par palier de la chaîne (A → S → SS → SSS), la couleur de l'étoile change, anneau, mini-flash, secousse |
| `fallEnd` – `boom` | **Temps d'arrêt** : l'étoile se contracte et aspire les petites étoiles |
| `boom` | **Éclat** : flash (≤ 0,7, SSS 0,85), rayons, éclats colorés, ondes de choc |
| `card` – `end` | **Carte** : jaillit en tournoyant (2 tours, + ½ tour par rareté), rebond de l'objet, reflet, lettres du palier, étoiles une à une, nom lettre par lettre |

Durées : B 14,4 s · A 15,3 s · S 16,8 s · SS 18,3 s · SSS 20,2 s (chute, arrêt et carte s'allongent avec la rareté, voir `fallExtra`, `hold` et `cardDur` dans `tiers.js`).
SSS ajoute les **fissures du ciel** au dernier battement.

### Multi ×10 (10 plumes)

1. Les 10 plumes descendent en couronne et se consument.
2. La charge, comme pour un single.
3. **Les 10 étoiles apparaissent l'une après l'autre**, dans l'ordre des tirages, et virevoltent en anneau dans le ciel. Chaque arrivée est plus longue et plus forte selon la rareté (`spawn`) :
   - **B** : l'étoile s'allume sur place.
   - **A** : elle descend de 14 blocs.
   - **S** : elle tombe de haut, avec un anneau dans le ciel et un mini-flash.
   - **SS** : elle tombe du zénith, avec des rayons dorés et une secousse.
   - **SSS** : elle arrive de l'horizon et fissure le ciel, avec des rayons rouges et une forte secousse.
4. Elles tombent toutes en spirale dans la vasque (décalage de 0,09 s). Les flammes s'allument, puis le noyau grossit à chaque étoile absorbée.
5. **Éclat** à la couleur du meilleur palier.
6. **10 cartes** sont distribuées face cachée devant le joueur (grille 5×2). Le dos est neutre : rien ne trahit la rareté avant l'anticipation. Les cartes se retournent dans l'ordre des tirages :
   - **B / A** : retournement rapide.
   - **S et plus** : anticipation (la carte tremble, se soulève, liseré de couleur), retournement d'un tour et demi pour SS/SSS, rayons, gerbe de particules, flash et secousse croissants.
7. Fin : la ou les meilleures cartes pulsent.

`multi_x10` = `B B B B B B A S SS SSS` (l'exemple demandé).
`multi_x10_double_sss` = deux SSS dans le même ×10 (deux arrivées fissurées, deux cartes rouges).

## Live ou pré-rendu

- **Live** : `GM.plan(pulls)` accepte n'importe quelle combinaison. La couleur de chaque étoile, la longueur de son arrivée et de son retournement viennent de son palier. C'est ce que fait le bouton « Random ×10 » du lecteur. En jeu : `T = (ticks + partialTick) / 20`, puis `state(plan, T)` à chaque frame.
- **Pré-rendu** : une vidéo par combinaison est impossible pour un ×10 (5¹⁰ combinaisons). Le live est donc la seule option pour le ×10. Un single pourrait être pré-rendu, mais Minecraft ne lit pas les vidéos, donc le live reste la voie naturelle.

## Portage vers Minecraft (Claude Code)

1. **Modèles** : refaire chaque `PART` de `altar.js` dans Blockbench, en cubes et en plaques. Les dimensions sont en blocs.
   - Les prismes à 5 à 8 côtés peuvent devenir des cubes tournés, pour un vrai rendu voxel.
   - Les flammes (`sprite flame`) deviennent des flammes voxelisées animées (empilement de cubes qui ondulent) ou une planche de sprites.
2. **Couleurs** : `tiers.js` (`PAL`, `TIERS`, `FLAMES`). Les couleurs signal des paliers sont celles de `GachaTier`.
3. **Timeline** : chaque `out/<anim>.timeline.json` donne les ancres (`anchors`), les battements (`beats`), les apparitions (`spawn`), les retournements (`flips`) et les **événements** (`events`, identifiants de son façon `SOUND_DESIGN.md`). Pour un lecteur Java générique, porter `timeline.js` + `state.js` tels quels, car ce ne sont que des maths.
4. **Caméra** : orbite autour de l'axe Y (`th` = intégrale d'une vitesse angulaire, jamais d'arrêt sec), avec rayon `R`, hauteur `H`, cible `TY` et focale `F` en courbes de clés. La cible se mélange à la position de l'étoile (`WS`).
5. **Rendu** : la 3D passe en `ModelPart` dans un `PoseStack`, en pleine lumière, avec la couleur calculée par `shade()` dans `renderer.js` (lune + lumières ponctuelles des flammes et de l'étoile). Halos, rayons, flash, cartes et police : blits GUI, en additif si autorisé (§ 3.2 du cahier des charges).
6. **Accessibilité** : au plus un flash par événement, toujours ≤ 0,7, sauf l'éclat SSS à 0,85. Aucun clignotement au-delà de 3 par seconde. Pour `reduceFlashes`, mettre `st.flash` et `st.shake` à 0.

## Limites connues

- Pas de son dans les MP4 : les événements sont dans les JSON.
- Les objets et noms (`END SHARD`, `DRAGON SCALE`, `VIOLET WINGS`…) sont des placeholders. Pour S et plus, la carte montre une icône d'ailes et non la vraie paire en 3D.
- Pas de mention New! / Duplicate, ni de mythiques (Night / Light).
- Tri du peintre sans z-buffer : quelques chevauchements de faces sont possibles quand la caméra frôle les ailes.
